## （七）参考文献

本节列出正文引用的全部 34 条文献，统一按"前三作者 + 等、单作者不缀'等'"的署名规则编号。条目采用统一格式：作者署名、论文标题、期刊卷（期）、页码、年份，并附 DOI 或 arXiv 编号。正文 [1]–[28] 对应立项依据、研究内容、研究方案三章正文；[29]–[34] 为研读基础文献，未在三章正文以 [N] 角标引用，另列分节并附与本项目研究方向的方法学关联。近三年（2024–2026）文献 19 条，占 55.9%；2011–2012 奠基文献 3 条（[5][23][24]），新旧配比兼顾。

### 正文引用文献（[1]–[28]）

[1] Cao Y., Fatemi V., Fang S. 等. *Correlated insulator behaviour at half-filling in magic-angle graphene superlattices*. **Nature 556(7699), 80–84 (2018)**. DOI: 10.1038/nature26154.

[2] Nuckolls K. P., Yazdani A. *A microscopic perspective on moiré materials*. **Nature Reviews Materials 9(7), 460–480 (2024)**. DOI: 10.1038/s41578-024-00682-1.

[3] Heide C., Kobayashi Y., Haque S. R. U. 等. *Ultrafast high-harmonic spectroscopy of solids*. **Nature Physics 20(10), 1546–1557 (2024)**. DOI: 10.1038/s41567-024-02640-8.

[4] Wang L., Yu B., Ciappina M. *MoS₂: A promising platform pushing the frontiers of experimental and theoretical nonlinear optical technologies*. **Matter 8(8), 102325 (2025)**. DOI: 10.1016/j.matt.2025.102325.

[5] Bistritzer R., MacDonald A. H. *Moiré bands in twisted double-layer graphene*. **Proceedings of the National Academy of Sciences 108(30), 12233–12237 (2011)**. DOI: 10.1073/pnas.1108174108.

[6] Molinero E. B., Datta A., Calderón M. J. 等. *High-Harmonic Generation with a twist: all-optical characterization of magic-angle twisted bilayer graphene*. **Optica 11(2), 171 (2024)**. DOI: 10.1364/OPTICA.510789.

[7] Ikeda T. N. *High-order nonlinear optical response of a twisted bilayer graphene*. **Physical Review Research 2(4), 032015 (2020)**. DOI: 10.1103/PhysRevResearch.2.032015.

[8] Mrudul M. S. *Dependence of high-harmonic generation in twisted bilayer graphene on laser pulse ellipticity*. **Physical Review B 110(11), 115415 (2024)**. DOI: 10.1103/PhysRevB.110.115415.

[9] Du L., Huang Z., Zhang J. 等. *Nonlinear physics of moiré superlattices*. **Nature Materials 23(9), 1179–1192 (2024)**. DOI: 10.1038/s41563-024-01951-8.

[10] Cao H., Sun J.-T., Meng S. *Floquet engineering of anomalous Hall effects in monolayer MoS₂*. **npj Quantum Materials 9(1), 90 (2024)**. DOI: 10.1038/s41535-024-00702-x.

[11] Silva R. E. F., Blinov I. V., Rubtsov A. N. 等. *High-harmonic spectroscopy of ultrafast many-body dynamics in strongly correlated systems*. **Nature Photonics 12(5), 266–270 (2018)**. DOI: 10.1038/s41566-018-0129-0.

[12] Ikeda R., Murakami Y., Sakai D. 等. *High-harmonic generation during ultrafast melting of a Mott insulating state*. **arXiv preprint arXiv:2508.00296 (2025)**.

[13] Luu T. T., Wörner H. J. *Measurement of the Berry curvature of solids using high-harmonic spectroscopy*. **Nature Communications 9(1), 916 (2018)**. DOI: 10.1038/s41467-018-03397-4.

[14] Hu S., Zhao H., Liu X.-B. 等. *Phonon-coupled high-harmonic generation for exploring nonadiabatic electron-phonon interactions*. **Physical Review Letters 133(15), 156901 (2024)**. DOI: 10.1103/PhysRevLett.133.156901.

[15] Shan J.-Y., Ye M., Chu H. 等. *Giant modulation of optical nonlinearity by Floquet engineering*. **Nature 600(7888), 235–239 (2021)**. DOI: 10.1038/s41586-021-04051-8；Erratum: **Nature 602(7895), E19 (2022)**, DOI: 10.1038/s41586-021-04368-4.

[16] Amato L., Müller M. *Ultrafast light-induced long-range antiferromagnetic correlations in paramagnets*. **Physical Review B 109(5), 054424 (2024)**. DOI: 10.1103/PhysRevB.109.054424.

[17] Zhou S., Bao C., Fan B. 等. *Pseudospin-selective Floquet band engineering in black phosphorus*. **Nature 614(7946), 75–80 (2023)**. DOI: 10.1038/s41586-022-05610-3.

[18] Tyulnev I., Jiménez-Galán Á., Poborska J. 等. *Valleytronics in bulk MoS₂ with a topologic optical field*. **Nature 628(8009), 746–751 (2024)**. DOI: 10.1038/s41586-024-07156-y.

[19] Lian Z., Meng Y., Ma L. 等. *Valley-polarized excitonic Mott insulator in WS₂/WSe₂ moiré superlattice*. **Nature Physics 20(1), 34–39 (2024)**. DOI: 10.1038/s41567-023-02266-2.

[20] Xiong R., Brantly S. L., Su K. 等. *Tunable exciton valley-pseudospin orders in moiré superlattices*. **Nature Communications 15(1), 4254 (2024)**. DOI: 10.1038/s41467-024-48725-z.

[21] Yao S., Lou Z., Ge X. 等. *Abnormal ellipticity dependence of high-harmonic generation induced by two-dimensional distributed Berry curvature*. **Photonics Research 13(5), 1235–1241 (2025)**. DOI: 10.1364/PRJ.549545.

[22] Peterka P., Slobodeniuk A., Novotný T. 等. *High harmonic generation in monolayer MoS₂ controlled by resonant and near-resonant pulses on ultrashort time scales*. **APL Photonics 8(8), 086103 (2023)**. DOI: 10.1063/5.0158995.

[23] Ghimire S., DiChiara A. D., Sistrunk E. 等. *Observation of high-order harmonic generation in a bulk crystal*. **Nature Physics 7(2), 138–141 (2011)**. DOI: 10.1038/nphys1847.

[24] Xiao D., Liu G.-B., Feng W. 等. *Coupled spin and valley physics in monolayers of MoS₂ and other group-VI dichalcogenides*. **Physical Review Letters 108(19), 196802 (2012)**. DOI: 10.1103/PhysRevLett.108.196802.

[25] Chang Lee V., Yue L., Gaarde M. B. 等. *Many-body enhancement of high-harmonic generation in monolayer MoS₂*. **Nature Communications 15(1), 6228 (2024)**. DOI: 10.1038/s41467-024-50534-3.

[26] Xiong R., Nie J. H., Brantly S. L. 等. *Correlated insulator of excitons in WSe₂/WS₂ moiré superlattices*. **Science 380(6647), 860–864 (2023)**. DOI: 10.1126/science.add5574.

[27] Kumar A., Chatterjee S., Watanabe K. 等. *Supermoiré-Trapped Quadrupolar Exciton*. **Nano Letters 26(31), 10547–10553 (2026)**. DOI: 10.1021/acs.nanolett.6c03005.

[28] Sun Y., Niedermeier M., Antão T. V. C. 等. *Self-consistent tensor network method for correlated super-moiré matter beyond one billion sites*. **Physical Review Research 7(4), 043288 (2025)**. DOI: 10.1103/krjp-mn4v.

### 研读基础文献（[29]–[34]）

[29] Seewald E., Ghosh S., Verma N. 等. *Mapping the moiré potential in multi-layer rhombohedral graphene*. **arXiv preprint arXiv:2510.09548 (2025)**. 方法学关联：STM/STS 直接可视化菱形石墨烯/hBN 莫尔势的实测锚点，为 §3.5 创新点三 graphene-hBN 推广候选材料提供 ~60 mV 振幅与 0.56° 空间 mapping 数据。已在 scheme §3.5 末段以 [29] 角标引用。

[30] Klein D. R., Zondiner U., Keren A. 等. *Imaging the Sub-Moiré Potential Landscape using an Atomic Single Electron Transistor*. **arXiv preprint arXiv:2410.22277 (2024)**. 方法学关联：量子扭曲显微镜（QTM）原子单电子晶体管对石墨烯/hBN 亚莫尔静电势成像的方法学锚，为 §3.5 创新点三 graphene-hBN 推广候选材料提供 1 nm 空间分辨率与 ~60 mV 振幅的实测参照。已在 scheme §3.5 末段以 [30] 角标引用。




