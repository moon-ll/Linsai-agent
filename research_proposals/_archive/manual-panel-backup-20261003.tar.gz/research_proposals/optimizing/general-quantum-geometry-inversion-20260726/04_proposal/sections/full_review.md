# 全文逻辑骨架

## 主线论证链

量子光场（BSV，$g^{(2)}(0) > 1$）与中等关联电子结构（$U/W \lesssim 1.0$）是 HHG 量子几何反演的两条独立边界。两条边界在 2023–2026 年间被独立突破（BSV 驱动固体 HHG[8]、Mott 熔化谐波红移[10]），但跨边界对接的 $\Omega/g$ 反演链路尚未建立。本项目以"BSV × 固体能带 × Berry/度规反演"三维交叉点为切入点，按 R1 → R2 → R3 → R4 四步递进，回答 Q1（光场统计边界）与 Q2（电子结构边界）两个可证伪科学问题：Q1 由 R1 量子态层级正向模型与 R3' BSV→CDW 迁移硬判据共同回答，Q2 由 R2 弱关联可辨识性闭环、R3 CDW 偏振基准与 Mott-CDW 红移、R4 PINN 跨关联强度相图共同回答。

## 章节衔接点

立项依据（rationale §1.3）把 2023–2026 年间相继突破的两条边界凝练为 Q1/Q2，给出放大比值三档判据与 $U/W$ 适用范围。研究内容（content §2.1–§2.5）显式编号 Q1/Q2 承接，把 Q1 落到 R1 + R3'、Q2 落到 R2 + R3 + R4 靶标上。研究方案（scheme §1–§7）按 R1 → R2 → R3 → R4 给出执行方案与各 R 节技术指标，与 content 章节号对齐（R3 任务 2 时间统一为"第 2 年四季度–第 3 年四季度"）。

四步逻辑链上的输入-输出衔接：R1 输出 BSV-SBE 三层量子态描述的工程边界（content §2.2 归属，scheme §2 实施）；R2 输出三独立可辨识性指标在 ZnO 同域闭环（content §2.3 归属，scheme §3 实施）；R3 输出 CDW 偏振基准与 Mott-CDW 红移判据（content §2.4 归属，scheme §4 实施）；R4 输出跨关联强度相图（content §2.5 归属，scheme §5 实施）。任一节点不达标时下一阶段目标主动收窄。

## 跨章节统一口径表

| 指标 | 数值/定义 | 出现位置 |
|------|-----------|---------|
| BSV 谐波产额下界（a-Si） | ≥ 10⁻⁵ photons/pulse（与 R2 通量预算同一身份） | content §2.2，scheme §2.3 |
| $g^{(2)}(0)$ 阈值 | > 1.5（HBT 标定，超泊松主判据） | content §2.2，scheme §2.3 |
| 截止阶次提升（ZnO 同码基线） | ≥ 15% | content §2.2，scheme §2.4 |
| CDW 相变温度（TiSe₂） | ~200 K | content §2.4.1，scheme §4.1 |
| 偏振各向异性突变判据 | ≥ 2° | content §2.4.1，scheme §4.4 |
| Ω 误差（弱关联同域 ZnO/MgO） | < 5% | content §2.5，scheme §5.4 |
| $g$ 误差（弱关联同域） | < 8% | content §2.5，scheme §5.4 |
| Ω 误差（弱→中关联外推档） | < 20% | content §2.5，scheme §5.4 |
| $g$ 误差（弱→中关联外推档） | < 30% | content §2.5，scheme §5.4 |
| Fisher 条件数判据 | $\text{cond}(\mathcal{I}) < 10$ | content §2.3，scheme §3.1 |
| 归一化内积判据 | $\lvert\rho_{\Omega g}\rvert < 0.3$ | content §2.3，scheme §3.1 |
| 后验相关系数判据 | $\lvert C_{\Omega g}\rvert < 0.3$ | content §2.3，scheme §3.1 |
| f-sum rule 阈值（弱关联同域） | < 5% | content §2.5，scheme §5.4 |
| f-sum rule 阈值（中等关联同域） | < $5\% \times (1 + 0.5 \cdot U/W)$ | content §2.5，scheme §5.4 |
| f-sum rule 阈值（弱→中外推档） | < $5\% \times (1 + 0.5 \cdot U/W) \times 1.5$ | content §2.5，scheme §5.4 |
| R3 任务 2 时间 | 第 2 年四季度–第 3 年四季度 | content §2.4.3，scheme §4.2 |
| R3 任务 2 红移判据 | $\Delta\omega/\omega > 2\%$，BSV-SBE 与实验偏差 < 单电子模型偏差 | content §2.4.3，scheme §4.4 |
| BSV-SBE 适用边界 | $r \leq 1.5$，主区 $U/W \leq 1.0$，扩展区 $U/W \leq 1.2$（含 1T-TaS₂ Mott-CDW 区），$n \leq 11$ | rationale §1.4，scheme 各 R 节 |
| 加性/乘性三档判据 | $\mathcal{R} < 1.2$ 无放大 / $1.2 \leq \mathcal{R} < 2$ 过渡放大 / $\mathcal{R} \geq 2$ 明显放大；同档一致判加性、跨档判乘性、两侧 < 1.2 判仅产额增强 | rationale §1.3，content §2.1/§2.4.2，scheme §2.2 |
| ZnO/MgO 谐波阶次 | 7–11 阶（12–19 阶仅作产额稳定性监测，不进入反演框架） | scheme §2.3/§6 |
| 1T-TaS₂ 相变序 | ~550 K IC → ~350 K NC → ~180 K NC→公度（Mott 化） | scheme §7.3 |
| Q1/Q2 阶段映射 | Q1 = R1 + R3'；Q2 = R2 + R3 + R4 | rationale §1.3，content §2.1 |

加性/乘性三档判据、HBT 验收协议、产额量纲与通量预算均以 03_method/method-manual.md 头部"判据口径表"为单一真相源。
