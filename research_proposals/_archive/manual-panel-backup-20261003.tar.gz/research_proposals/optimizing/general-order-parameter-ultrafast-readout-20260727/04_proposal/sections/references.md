## （七）参考文献

---

### 1. 超导序参量 HHG（背景对照）

[1] Kawakami, Y., Amano, T., Ohashi, H., Itoh, H., Nakamura, Y., Kishida, H., Sasaki, T., Kawaguchi, G., Yamamoto, H. M., Yamamoto, K., Ishihara, S., Yonemitsu, K. & Iwai, S. Petahertz non-linear current in a centrosymmetric organic superconductor. *Nat. Commun.* **11**, 4138 (2020). DOI: 10.1038/s41467-020-17776-3; arXiv:2007.10762. 【正式发表】【关联：拍赫兹电流与 HHG 相干性的早期有机超导实现，对照序参量响应的另一类途径】

[2] Matsunaga, R., Tsuji, N., Makise, K., Terai, H., Aoki, H. & Shimano, R. Polarization-resolved terahertz third-harmonic generation in a single-crystal superconductor NbN: Dominance of the Higgs mode beyond the BCS approximation. *Phys. Rev. B* **96**, 020505(R) (2017). DOI: 10.1103/PhysRevB.96.020505. 【正式发表】【关联：NbN 单晶上 Higgs 模在三次谐波响应中的主导地位，对照序参量振幅响应的非线性协议】

[3] Alcalà, J., Bhattacharya, U., Biegert, J., Ciappina, M., Elu, U., Graß, T., Grochowski, P. T., Lewenstein, M., Palau, A., Sidiropoulos, T. P. H., Steinle, T. & Tyulnev, I. High-harmonic spectroscopy of quantum phase transitions in a high-Tc superconductor. *Proc. Natl. Acad. Sci. U.S.A.* **119**, e2207766119 (2022). DOI: 10.1073/pnas.2207766119. 【正式发表】【关联：高 Tc 超导相变的 HHG 谱学方案，序参量量子相变的另一类载体】

[4] Puviani, M. Theory of symmetry-resolved quench-drive spectroscopy: Nonlinear response of phase-fluctuating superconductors. *Phys. Rev. B* **109**, no. 21, 214515 (2024). DOI: 10.1103/PhysRevB.109.214515; arXiv:2402.02120. 【正式发表】【关联：淬灭—驱动谱学的对称分辨理论，与 §三.3 多带 SBE 正演协议同属非线性响应框架】

[5] Li, X. & Weng, Z.-Y. Terahertz nonlinear response in cuprate superconductors and the Higgs field in doped Mott insulators. *Phys. Rev. B* **113**, no. 3, 035106 (2026). DOI: 10.1103/dvy6-r5sr; arXiv:2509.08370 (2025-09)，终稿于 2026 年正式上线。 【正式发表】【关联：Higgs 场在掺杂 Mott 绝缘体中的太赫兹非线性响应框架，HHG 路径与该太赫兹协议互为序参量探测的频段互补】

---

### 2. 电荷密度波 HHG（对照体系 TiSe₂）

[6] Tyulnev, I., Zhang, L., Vamos, L., Poborska, J., Bhattacharya, U., Chhajlany, R. W., Grass, T., Mañas-Valero, S., Coronado, E., Lewenstein, M. & Biegert, J. High harmonic spectroscopy reveals anisotropy of the charge-density-wave phase transition in TiSe₂. *Commun. Mater.* **6**, no. 1, 152 (2025). DOI: 10.1038/s43246-025-00873-5; arXiv:2409.04216. 【正式发表】【关联：TiSe₂ CDW 相变（约 200 K 以下）的偏振不对称 3/5/7 阶谐波实验观测，本项目 G1 复现判据的实验层锚点（方向一致 + 幅度偏差 ≤ 10%）】

[7] Zhang, L., Tyulnev, I., Vamos, L., Poborska, J., Bhattacharya, U., Chhajlany, R. W., Grass, T., Biegert, J. & Lewenstein, M. Revealing the anisotropic charge-density-wave order of TiSe₂ through high harmonic generation. *Phys. Rev. B* **112**, no. 8, 085147 (2025). DOI: 10.1103/812z-nl4m; arXiv:2412.13329 (v2, 2025-08-26). 【正式发表】【关联：TiSe₂ CDW 各向异性 HHG 的理论复现，对应 G1 正演—反演层幅度判据的参数迁移锚点，不进入偏差计算口径】

[8] Ahmed, T., Yoo, J., Prasankumar, R. & Zhu, J.-X. A real-time TDDFT study of femtosecond laser driven monolayer NbSe₂. arXiv:2008.07131 (v2, 2020-12-17). 【预印本】【关联：NbSe₂ 单层 CDW 的实时 TDDFT HHG 计算，与 [9] 的解析理论方法学互补】

[9] Rehn, D. A., Ahmed, T., Padmanabhan, P., Yoo, J., Prasankumar, R. & Zhu, J.-X. Theoretical study of high harmonic generation in monolayer NbSe₂. *J. Phys. Chem. C* **130**, no. 4, 1551—1561 (2026). DOI: 10.1021/acs.jpcc.5c05450; arXiv:2310.03080. 【正式发表】【关联：NbSe₂ 单层 HHG 的解析理论，与 [8] 的实时 TDDFT 形成方法学互补】

[10] Dziurawiec, M., de Almeida, J. O., Bera, M. L., Płodzień, M., Lewenstein, M., Grass, T., Chhajlany, R. W., Maśka, M. M. & Bhattacharya, U. High harmonic tracking of ultrafast electron dynamics across the Mott to charge-density-wave phase transition. *Phys. Rev. B* **113**, no. 7, 075117 (2026). DOI: 10.1103/bl2s-cv34; arXiv:2404.14411. 【正式发表】【关联：Mott—CDW 相变跨度的 HHG 电子动力学跟踪，与 §一.2 多通道混合警示同源的另一对照载体】

---

### 3. 关联体系、激子、多体 HHG 与国内材料工程（方法学警示与样品基础）

[11] Shao, T.-H., Dai, X., Hu, W. *et al.* Epitaxial growth and anomalous Hall effect in high-quality altermagnetic α-MnTe thin films. arXiv:2602.11645 (v1, 2026-02-12). 【预印本】【关联：MBE 在 InP(111) 上外延厘米级 α-MnTe 薄膜，近零净磁矩下观测到源于 Berry 曲率的反常霍尔效应，§一.2 国内研究现状层的样品工程证据（南方科技大学团队）】

[12] Murakami, Y., Hansen, T., Takayoshi, S., Madsen, L. B. & Werner, P. Many-body effects on high-harmonic generation in Hubbard ladders. *Phys. Rev. Lett.* **134**, no. 9, 096504 (2025). DOI: 10.1103/PhysRevLett.134.096504; arXiv:2407.01936. 【正式发表】【关联：Hubbard 梯上多体效应对 HHG 的修正——相干 doublon-holon 对、自旋弦、自旋极化子与磁振子三激发过程均贡献可分辨谱平台，§一.2 多通道混合警示的直接理论锚点】

[13] Jensen, S. V. B., Madsen, L. B., Rubio, A. & Tancogne-Dejean, N. High-harmonic spectroscopy of strongly bound excitons in solids. *Phys. Rev. A* **109**, no. 6, 063104 (2024). DOI: 10.1103/PhysRevA.109.063104; arXiv:2307.14693. 【正式发表】【关联：固体中强束缚激子的 HHG 谱学，激子凝聚的 HHG 响应涉及束缚态相干性，与磁序对称破缺机制独立（§一.3 范围限定说明）】

[14] Hu, S.-Q., Chen, D.-Q., Du, L.-L. & Meng, S. Solid-state high harmonic spectroscopy for all-optical band structure probing of high-pressure quantum states. *Proc. Natl. Acad. Sci. U.S.A.* **121**, no. 6, e2316775121 (2024). DOI: 10.1073/pnas.2316775121. 【正式发表】【关联：高压量子态的固体 HHG 全光带结构探测，国内孟胜组的方法学铺垫工作，§一.4 国内研究层的并列】

---

### 4. 磁序与交错磁 HHG（核心主攻方向）

[15] Takayoshi, S., Murakami, Y. & Werner, P. High-harmonic generation in quantum spin systems. *Phys. Rev. B* **99**, no. 18, 184303 (2019). DOI: 10.1103/PhysRevB.99.184303; arXiv:1901.07588. 【正式发表】【关联：一维量子自旋系统磁性 HHG 的一般理论基础，与 [16] 同属磁序 HHG 方向的方法学锚点】

[16] Werner, P., Lysne, M. & Murakami, Y. High harmonic generation in altermagnets. *Phys. Rev. B* **110**, no. 23, 235101 (2024). DOI: 10.1103/PhysRevB.110.235101; arXiv:2407.07752. 【正式发表】【关联：交错磁 HHG 的两个 SOC 极限——偶次谐波依赖外磁场（SOC 可忽略）与高能峰/谐波平台/圆二色性/自旋流谐波（SOC 充分强），§三.2 SOC 有效值连续参数化的理论依据】

[17] Šmejkal, L., Sinova, J. & Jungwirth, T. Beyond conventional ferromagnetism and antiferromagnetism: A phase with nonrelativistic spin and crystal rotation symmetry. *Phys. Rev. X* **12**, no. 3, 031042 (2022). DOI: 10.1103/PhysRevX.12.031042; arXiv:2105.05820. 【正式发表】【关联：交错磁作为独立磁性相的对称性分类与 Kramers 自旋简并提升框架，CrSb 波型口径 d 波主对称性分类依据】

[18] Leeb, V., Mook, A., Šmejkal, L. & Knolle, J. Spontaneous formation of altermagnetism from orbital ordering. *Phys. Rev. Lett.* **132**, no. 23, 236701 (2024). DOI: 10.1103/PhysRevLett.132.236701; arXiv:2312.10839. 【正式发表】【关联：轨道有序自发形成交错磁的微观机制，§一.2 序参量生成机制的方法学参照】

[19] Ly, O. High-harmonic spin and charge pumping in altermagnets. *J. Phys.: Condens. Matter* **38**, no. 17, 175803 (2026). DOI: 10.1088/1361-648X/ae6385; arXiv:2602.09738 (v3 current, 2026-04-20). 【正式发表】【关联：磁序进动驱动下交错磁体的高阶自旋与电荷泵浦谐波，与本项目外磁场反转差分协议在操控变量维度互补】

[20] Wang, C., Wang, Y. & Meng, S. Ultrafast altermagnetophononics. arXiv:2607.13863 (v1, 2026-07-15). 【预印本】【关联：相干声子路径实现 MnTe 与 CrSb 中交错磁体到补偿亚铁磁的瞬态转变，国内孟胜组的样品可行性间接证据（皮秒超快尺度磁序调控）】

[21] Yang, X., Cheng, X., Deng, Z., Gao, Y.-H., Yang, Q.-L., Chang, Z., Yang, P.-T., Feng, H.-M., Zhang, X.-Q., He, W., Liu, J. & Cheng, Z.-H. Ultrafast magneto-optical fingerprints of altermagnetism in MnTe. *Phys. Rev. Lett.* **136**, no. 25, 256702 (2026). DOI: 10.1103/nyy3-h8wr; arXiv:2605.24320. 【正式发表】【关联：MnTe 30 nm 薄膜中 Kerr（动量空间 Berry 曲率）与 Voigt（实空间 Néel 各向异性）效应的共存，时间分辨磁光手段对交错磁序参量相关对称性的早期直接观测】

[22] Liu, Y. Q., Si, M. S., Zhang, G. P., Du, H. & Zhang, Z. M. Anisotropic high harmonic generation as a gauge of altermagnetism in RuO₂. *Phys. Rev. B* **112**, L081105 (2025). DOI: 10.1103/9gv7-vhxw. 【正式发表】【关联：RuO₂ 上 HHG 取向依赖的"哑铃/三叶草"形状作为交错磁性判别指纹的第一性原理计算，CrSb/MnTe 体相 HHG 谱形预期的具体参照】

[23] Ma, Y. X., Chang, J. Z., Liu, Y. D., Si, M. S., Zhang, G. P. & Zhang, Z. M. Probing spin-split bands in altermagnets through second harmonic generation. *Phys. Rev. B* **111**, no. 6, 064311 (2025). DOI: 10.1103/PhysRevB.111.064311. 【正式发表】【关联：动量分辨 SHG 识别 RuO₂/CuF₂/MnTe 自旋分裂能带的理论方案（三阶 Pancharatnam-Berry 张量计算），HHG 路径之外的二阶非线性参照系】

---

### 5. CrSb 与 MnTe 的材料学基准

[24] Sankar, S., Cheng, X., Chen, X. *et al.* Broadband nonlinear Hall response and multiple wave mixing in a room temperature altermagnet. arXiv:2511.10471 (v1, 2025-11-13). 【预印本】【关联：室温 CrSb 宽带三阶非线性反常霍尔效应，HHG 强场驱动下信号可探测性的非线性光学独立依据】

[25] Terashima, T., Hattori, Y., Graf, D., Urata, T., Yoshioka, T., Hattori, W., Ikuta, H. & Ikeda, H. Altermagnetic spin-split Fermi surfaces in CrSb revealed by quantum oscillation measurements. arXiv:2601.19105 (v2, 2026-07-15). 【预印本】【关联：CrSb 量子振荡测量的多条自旋非简并频率分支，体态电子结构的独立基准】

[26] Paul, S., Ikeda, A., Mattoni, G., Yonezawa, S. & Sow, C. Thermodynamic and transport properties of high-quality single crystals of the altermagnet CrSb. *Phys. Rev. Materials* **10**, no. 6, 063402 (2026). DOI: 10.1103/hnjw-k826; arXiv:2603.02835. 【正式发表】【关联：高质量 CrSb 单晶的磁化率、比热与电阻基准，与 d 波交错磁自旋分裂费米面解释一致的体态电子结构独立基准】

[27] Singh, A. K., Heinsdorf, N., Mancilla, A. A. *et al.* Coherent high-velocity chiral magnons in the metallic altermagnet CrSb. arXiv:2511.16086 (current version cited: v2, 2026-05-13). 【预印本】【关联：CrSb 在 TN = 733(4) K 以下为完美补偿伊辛型交错磁体（极化中子衍射 + 磁化率标定），Γ-L 方向首次观测手性自旋分裂磁振子；本课题 733(4) K Néel 温度与磁结构基准均引此条】

---

### 6. 实验方法、变量控制与正演模型适用边界

[28] Mandal, S., Kumar, P., Pi, Z., Kim, H. Y., Zhan, M. & Goulielmakis, E. A precision apparatus for high harmonic spectroscopy in bulk solids. *Rev. Sci. Instrum.* **97**, no. 4, 045209 (2026). DOI: 10.1063/5.0316448; arXiv:2512.13311. 【正式发表】【关联：体相固体 HHG 谱学的精密装置方案，本项目 §三.3 装置参数设定的工程参照（精度与光路对齐）】

[29] Yue, L. & Gaarde, M. B. Structure gauges and laser gauges for the semiconductor Bloch equations in high-order harmonic generation in solids. *Phys. Rev. A* **101**, no. 5, 053411 (2020). DOI: 10.1103/PhysRevA.101.053411; arXiv:2003.02961. 【正式发表】【关联：固体 HHG 中 SBE 的结构规范与光场规范选择，§三.2 多带 SBE 正演的规范依据】

[30] Wang, S., He, X., Liang, Y., Su, Y., Fang, S. & Wei, Z. Transition from multiphoton to tunneling ionization in the process of high harmonic generation in solids. arXiv:2208.10032 (v1, 2022-08-22). 【预印本】【关联：固体 HHG 多光子—隧穿渡越区划分，§三.3 γ ≈ 0.21—0.95 跨渡越区判据的理论依据】

[31] Zhang, Z., Ning, H., Liu, Z.-J., Hou, J., Mohite, A. D., Baldini, E., Gedik, N. & Nelson, K. A. Keldysh tuning of photoluminescence in a lead halide perovskite crystal. *Proc. Natl. Acad. Sci. U.S.A.* **122**, no. 33, e2426253122 (2025). DOI: 10.1073/pnas.2426253122; arXiv:2407.15253. 【正式发表】【关联：卤化铅钙钛矿 PL 的 Keldysh 调谐，HHG 强场驱动下限与光场—物质耦合工程边界的横向方法学参照】

[32] Uzner, E. & Neufeld, O. Ultrafast spectroscopy and role of interlayer coupling in high harmonic generation from layered solids. arXiv:2604.23506 (v1, 2026-04-26). 【预印本】【关联：层状固体中 HHG 的层间耦合效应，§三.3 偏振分辨 HHG 在薄层/体相几何切换时的方法学参照】

[33] Granados, C., Shrestha, R., Das, B. K., Rajak, D., Cormier, E., Kiss, B., Rosales-Guzman, C., Gao, W. *et al.* Carrier-envelope phase control of orbital angular momentum in solid-state high-harmonic generation. arXiv:2607.23652 (v1, 2026-07). 【预印本】【关联：少周期涡旋光驱动 ZnO HHG 中 CEP 对谐波拓扑电荷的切换，§三.3 装置 CEP 稳定度指标的工程参照】

---

### 7. 综述

[34] Li, L., Lan, P., Zhu, X. & Lu, P. High harmonic generation in solids: Particle and wave perspectives. *Rep. Prog. Phys.* **86**, no. 11, 116401 (2023). DOI: 10.1088/1361-6633/acf144; arXiv:2304.12547. 【正式发表】【综述】【关联：固体 HHG 的粒子与波动双视角综述，国内兰鹏飞/陆培祥组的总结性工作，§一.4 国内研究层并列】

---

### 8. 辅助验证维度的方法学锚点

[35] Rajak, D., Das, B. K., Shrestha, R., Kiss, B., Cormier, E., Rosales-Guzman, C., Fritzsche, S., Zhan, Q., Gao, W. & Granados, C. Twisting harmonics: Transfer of orbital angular momentum in solid-state high-harmonic generation. arXiv:2601.12743 (v1, 2026-01-19). 【预印本】【关联：固体 HHG 中 OAM 从驱动场到发射谐波的标度律转移，§三.3 装置涡旋光模式的备选探测路径】

---

### 9. 交错磁自旋分裂的实验直接观测与温度演化

[36] Long, M., Weinberger, T. I., Wu, Z., Hansen, M. F., Tao, R., Shrestha, M., Graf, D., Skourski, Y., Grosche, F. M. & Eaton, A. G. 3D bulk-resolved g-wave altermagnetic order parameter in CrSb. *Nature* **656**, 854—860 (2026). DOI: 10.1038/s41586-026-10902-z; arXiv:2601.14526 (v2, 2026-07-13，正式版 2026-08-26 上线). 【正式发表】【关联：CrSb 三维体分辨 g 波交错磁序参量的 dHvA 节点证认，g 波对称性的实验直接观测；与 [17] d 波分类构成开放争议，由项目第 1 年 dHvA 角谱节点校准给出前置判据】

[37] Krempaský, J., Šmejkal, L., D'Souza, S. W., Hajlaoui, M., Springholz, G., Uhlířová, K., Alarab, F., Constantinou, P. C., Strocov, V., Usanov, D., Pudelko, W. R., González-Hernández, R., Birk Hellenes, A., Jansa, Z., Reichlová, H., Šobáň, Z., Gonzalez Betancourt, R. D., Wadley, P., Sinova, J., Kriegner, D., Minár, J., Dil, J. H. & Jungwirth, T. Altermagnetic lifting of Kramers spin degeneracy. *Nature* **626**, 517—522 (2024). DOI: 10.1038/s41586-023-06907-7. 【正式发表】【关联：MnTe ARPES 测得 Kramers 自旋简并的交错磁提升，非高对称动量点分裂达 0.8 eV，CrSb 候选信号机制的前置实验依据】

[38] Osumi, T., Souma, S., Aoyama, T., Yamauchi, K., Honma, A., Nakayama, K., Takahashi, T., Ohgushi, K. & Sato, T. Observation of giant band splitting in altermagnetic MnTe. *Phys. Rev. B* **109**, 115102 (2024). DOI: 10.1103/PhysRevB.109.115102; arXiv:2308.10117. 【正式发表】【关联：MnTe ARPES 直接观测到动量依赖自旋分裂，§一.4 候选信号机制的实测锚点】

[39] Woodgate, C. D., Menai, N., Ernst, A. & Staunton, J. B. Loss of altermagnetic order and smooth restoration of Kramers' spin degeneracy with increasing temperature in CrSb and MnTe. arXiv:2603.15035 (v1, 2026-03-16). 【预印本】【关联：温度依赖无序局域矩（DLM）第一性原理计算——金属 CrSb 在远低于 TN 即被热无序削弱、半导体 MnTe 接近 310 K 才恢复自旋简并，§三.2 温度修正曲线的理论基准】

---

### 10. 磁群形式化与 SOC 面内分量

[40] Mineev, V. P. Band splitting in the altermagnet CrSb. *Phys. Rev. B* **114**, 065130 (2026). DOI: 10.1103/mytl-kml2; arXiv:2602.15131 (v3, 2026-07-08). 【正式发表】【关联：磁群形式化分析 CrSb 节点面上 SOC 诱导的附加自旋分量，§三.2 SOC 节点面劈裂语境的群论基础】

---

### 11. CrSb 平带驱动的电荷—自旋竞争与 Kohn 异常

[41] Korshunov, A., Alkorta, M., Lim, C.-Y., Ballester, F., Li, C., Li, Z., Chernyshov, D., Bosak, A., Vergniory, M. G., Errea, I. & Blanco-Canosa, S. Flat band driven competing charge and spin instabilities in the altermagnet CrSb. arXiv:2603.25317 (v1, 2026-03-26). 【预印本】【关联：CrSb 中 M 点短程电荷涨落与 ~6 meV 量级 Kohn 异常的 X 射线漫散射 + 非弹性散射观测，提示顺磁相已具备形成 CDW 的能带原料】

---

### 12. CrSb 自旋激发（手性磁振子）多体微扰

[42] Tas, M. The magnon spectra of g-type altermagnet bulk CrSb. arXiv:2510.03759 (v1, 2025-10-06). 【预印本】【关联：CrSb g 波交错磁振子谱与手性寿命的多体微扰计算，能量达 275 meV（K 点），Γ-L 方向手性寿命差约 20 fs】

---

### 13. 弱 SOC 极限的非相对论通道（HHG 候选信号的扩展约束）

[43] Liu, D., Zhuang, Z.-Y., Zhu, D., Wu, Z. & Yan, Z. Nonrelativistic spin-orbit-coupling effects in odd-parity coplanar magnets. arXiv:2606.23806 (v1, 2026-06-22). 【预印本】【关联：奇宇称共面磁体中非相对论 SOC 效应，§一.2 弱 SOC 极限下 HHG 候选信号的多通道扩展约束】

---

### 14. 国内 CrSb 单晶生长与磁输运（样品可获得性）

[44] Bai, Y., Xiang, X., Pan, S., Zhang, S., Chen, H., Chen, X., Han, Z., Xu, G. & Xu, F. Nonlinear field dependence of Hall effect and high-mobility multi-carrier transport in an altermagnet CrSb. *Appl. Phys. Lett.* **126**, 042402 (2025). DOI: 10.1063/5.0240434; arXiv:2409.14855. 【正式发表】【关联：高质量 CrSb 单晶的生长与磁输运测量，霍尔非线性经三载流子分析溯源至多带输运而非自旋分裂 Berry 曲率，§一.2 国内 CrSb 单晶生长与磁输运的编号锚点（南京理工大学团队）】

---

### 15. g 波对称性与手性磁振子理论（R2 偏振配置与自旋激发证据链）

[45] Kravchuk, V. P., Yershov, K. V., Facio, J. I., Guo, Y., Janson, O., Gomonay, O., Sinova, J. & van den Brink, J. Chiral magnetic excitations and domain textures of g-wave altermagnets. *Phys. Rev. B* **112**, no. 14, 144421 (2025). DOI: 10.1103/zn8d-ft9b; arXiv:2504.05241. 【正式发表】【关联：g 波交错磁体磁激发理论——易轴型 CrSb 的手性磁振子劈裂保持 g 波对称且不受易轴各向异性改变，§二.3 面内角分布指纹作为低温磁有序相内稳定判据的理论依据】

[46] Zhang, Y.-F., Ni, X.-S., Chen, K. & Cao, K. Chiral magnon splitting in altermagnetic CrSb from first principles. *Phys. Rev. B* **111**, 174451 (2025). DOI: 10.1103/PhysRevB.111.174451; arXiv:2503.12920. 【正式发表】【关联：第一性原理（LSWT + TD-DFPT）预言 CrSb 手性磁振子劈裂由等长而对称不等价的第 11、12 近邻交换通道（J₁₁/J₁₂）驱动，与 [27] 的非弹性中子散射观测构成预言—证实证据链，§二.3 高阶交错磁交换相互作用的预言侧锚点】

[47] Mizuno, K. High-harmonic spin-current signatures of altermagnetic spin-group symmetry. arXiv:2606.31573 (v1, 2026-06). 【预印本】【关联：自旋点群框架下电荷/自旋电流 HHG 选择定则——沿晶轴线偏振驱动下铁磁与交错磁相位选择定则相同、对角线偏振与单螺旋度圆偏振恢复相位分辨；其对象为弱 SOC 极限的自旋电流谐波，§二.3 偏振方位角取点避开高对称方向简并窗口的定则参照】

---

### 16. 磁结构稳定性与自旋翻转场（磁场反转差分的前提把关）

[48] Yu, T., Shahid, I., Liu, P., Chen, X.-Q. & Sun, Y. Néel vector-dependent anomalous transport in altermagnetic metal CrSb. arXiv:2412.12882 (current version cited: v4). 【预印本】【关联：第一性原理计算 CrSb 不同 Néel 矢量取向间总能量差小于 1 meV、磁晶各向异性能偏弱，各向异性场 B_K 相应较小，§三.3 B_SF ≈ √(2B_E·B_K) 量级估算的 B_K 端约束】

[49] Grzybowski, M. J., Schippers, C. F., Gomonay, O., Rubi, K., Bal, M. E., Zeitler, U., Kozioł-Rachwał, A., Szpytma, M., Janus, W., Kurowska, B., Kret, S., Gryglas-Borysiewicz, M., Koopmans, B. & Swagten, H. J. M. Antiferromagnetic hysteresis above the spin flop field. *Phys. Rev. B* **107**, L060403 (2023). DOI: 10.1103/PhysRevB.107.L060403; arXiv:2109.00093. 【正式发表】【关联：CoO 自旋翻转场（240 K 下 7.0 T）以上反铁磁迟滞持续至 30 T，磁晶各向异性随磁场变化引入迟滞，§三.3 ±B 升降场迟滞预检设计的方法学先例】

---
