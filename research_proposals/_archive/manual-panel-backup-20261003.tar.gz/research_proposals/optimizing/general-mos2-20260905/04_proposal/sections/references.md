## 参考文献

[1] S. Ghimire et al., Nat. Phys. 7, 138 (2011); doi:10.1038/nphys1847.

[2] O. Schubert et al., Nat. Photon. 8, 119 (2014); doi:10.1038/nphoton.2013.349.

[3] T. T. Luu et al., Nature 521, 498 (2015); doi:10.1038/nature14456.

[4] G. Ndabashimiye et al., Nature 534, 520 (2016); doi:10.1038/nature17660.

[5] Y. S. You, D. A. Reis, and S. Ghimire, Nat. Phys. 13, 345 (2017); doi:10.1038/nphys3955.

[6] H. Kim et al., ACS Photon. 4, 1627 (2017); doi:10.1021/acsphotonics.7b00350.

[7] N. Yoshikawa, T. Tamaya, and K. Tanaka, Science 356, 736 (2017); doi:10.1126/science.aam8861.

[8] M. Taucer, arXiv:1808.09288 (2018).

[9] G. Vampa et al., Phys. Rev. B 91, 064302 (2015); doi:10.1103/PhysRevB.91.064302.

[10] N. Tancogne-Dejean, O. D. Mücke, F. X. Kärtner, and A. Rubio, Phys. Rev. Lett. 118, 087403 (2017); doi:10.1103/PhysRevLett.118.087403.

[11] E. N. Osika et al., Phys. Rev. X 7, 021017 (2017); doi:10.1103/PhysRevX.7.021017.

[12] L. Li et al., Phys. Rev. Lett. 122, 193901 (2019); doi:10.1103/PhysRevLett.122.193901.

[13] C. Heide et al., Nanophotonics 12, 255 (2023); doi:10.1515/nanoph-2022-0595.

[14] J. Freudenstein et al., Nature 610, 290 (2022); doi:10.1038/s41586-022-05190-2.

[15] P. Peterka et al., APL Photonics 8, 086103 (2023); doi:10.1063/5.0158995.

[16] T. N. Ikeda, Phys. Rev. Research 2, 032015 (2020); doi:10.1103/PhysRevResearch.2.032015.

[17] B. R. Nebgen et al., Sci. Adv. 12, eadz5621 (2026); doi:10.1126/sciadv.adz5621.

[18] L. Yue and M. B. Gaarde, Phys. Rev. Lett. 124, 153204 (2020); doi:10.1103/PhysRevLett.124.153204.

[19] H. Liu et al., Nat. Phys. 13, 262 (2017); doi:10.1038/nphys3946.

[20] Y. Lee, D. Kim, A. Chacón, and D. E. Kim, Symmetry 13, 2403 (2021); doi:10.3390/sym13122403.

[21] V. Chang Lee et al., Nat. Commun. 15, 6228 (2024); doi:10.1038/s41467-024-50534-3.

[22] C. Ma et al., Phys. Rev. Lett. 135, 166902 (2025); doi:10.1103/PhysRevLett.135.166902.

[23] Q.-G. Fan et al., Comput. Mater. Sci. 268, 114641 (2026); doi:10.1016/j.commatsci.2026.114641.

[24] H. Zhong, X. Cai, C. Bao et al., Ultrafast Sci. 4, 0063 (2024); doi:10.34133/ultrafastscience.0063.

[25] X. Liu et al., Appl. Phys. Lett. 126, 191101 (2025); doi:10.1063/5.0266306.

[26] S.-Q. Hu, D.-Q. Chen, L.-L. Du, and S. Meng, Proc. Natl. Acad. Sci. USA 121, e2316775121 (2024); doi:10.1073/pnas.2316775121.

[27] A. Cárdenas, R. E. F. Silva, and Á. Jiménez-Galán, arXiv:2604.13901 (2026).

[28] S. Patra and C. Cocchi, arXiv:2607.19937 (2026).

[29] E. B. Molinero et al., Optica 11, 171 (2024); doi:10.1364/OPTICA.510789.

[30] M. S. Mrudul, Phys. Rev. B 110, 115415 (2024); doi:10.1103/PhysRevB.110.115415.

[31] J. O. de Almeida, W. J. M. Kort-Kamp, and M. S. Scheurer, arXiv:2604.11984 (2026).

[32] H. K. Avetissian, H. H. Matevosyan, and G. F. Mkrtchian, Phys. Rev. B 111, 045415 (2025); doi:10.1103/PhysRevB.111.045415.

[33] S. V. B. Jensen, L. B. Madsen, A. Rubio, and N. Tancogne-Dejean, Phys. Rev. A 109, 063104 (2024); doi:10.1103/PhysRevA.109.063104.

[34] M.-H. Chiu et al., Nat. Commun. 6, 7666 (2015); doi:10.1038/ncomms8666.

[35] T. T. Luu and H. J. Wörner, Nat. Commun. 9, 916 (2018); doi:10.1038/s41467-018-03397-4.

[36] G. Bae, Y. Kim, and J. D. Lee, Phys. Rev. B 106, 205422 (2022); doi:10.1103/PhysRevB.106.205422.

[37] A. T. Bondy, J. C. del Valle, S. Saha et al., arXiv:2404.02985 (2024).

[38] V. V. Serov and A. S. Kheifets, arXiv:2606.10272 (2026).

[39] M. Kim, T. Kim, A. Galler et al., Nat. Commun. 16, 9825 (2025); doi:10.1038/s41467-025-65725-9.

[40] J. Gao et al., arXiv:2508.14774 (2025).

[41] T. Csizmadia et al., APL Photonics 10, 080803 (2025); doi:10.1063/5.0273558.

---

研读基础：[2]–[7]、[10]、[14]、[18]–[21]、[27]、[29]–[33]、[36]–[38]、[41] 等条目为 HHG 在大带隙半导体、绝缘体、多层体系与 Berry 反演路径推广的奠基性背景，按范本允许的"研读基础"标准列入文末，不参与逐条编号引用。论证主链由 [1, 3, 4, 5, 6, 8, 9, 11, 12, 13, 15, 16, 17, 22, 23, 24, 25, 26, 28, 34, 35, 39, 40] 等条目直接承担。
