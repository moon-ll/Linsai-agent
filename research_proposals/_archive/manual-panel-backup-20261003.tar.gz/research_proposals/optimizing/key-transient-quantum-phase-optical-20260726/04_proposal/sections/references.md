## （七）参考文献

带 † 前缀者为 arXiv 预印本，其余为期刊正式发表条目。作者超过三人时列前三作者加 "et al."；DOI 形态保留出版方原始注册形式（短式与长式并存，不做机械统一）。

[1] Thouless D.J., Kohmoto M., Nightingale M.P., et al. Quantized Hall conductance in a two-dimensional periodic potential. *Phys. Rev. Lett.*, 1982, 49: 405-408. DOI: 10.1103/PhysRevLett.49.405

[2] Haldane F.D.M. Model for a quantum Hall effect without Landau levels: condensed-matter realization of the "parity anomaly". *Phys. Rev. Lett.*, 1988, 61: 2015-2018. DOI: 10.1103/PhysRevLett.61.2015

[3] Ono A., Okumura S., Imai S., et al. High harmonic generation from electrons moving in topological spin textures. *Phys. Rev. B*, 2024, 110: 125111. DOI: 10.1103/PhysRevB.110.125111

[4] †Borrego-Varillas R., Agostini P., Ardana-Lamas F., et al. Roadmap on attosecond science. arXiv:2604.15085, 2026.

[5] Ciappina M.F. Solid-state high-order harmonic generation: emerging frontiers in ultrafast and quantum light science. *Adv. Phys.*, 2025, 74: 1-9. DOI: 10.1080/00018732.2025.2598130

[6] Ghimire S., DiChiara A.D., Sistrunk E., et al. Observation of high-order harmonic generation in a bulk crystal. *Nat. Phys.*, 2011, 7: 138-141. DOI: 10.1038/nphys1847

[7] Baykusheva D., Chacón A., Kim D., et al. Strong-field physics in three-dimensional topological insulators. *Phys. Rev. A*, 2021, 103: 023101. DOI: 10.1103/PhysRevA.103.023101

[8] Di Gaspare A., Ghayeb S., Knox C., et al. Second harmonic generation and third harmonic generation in topological insulator-based van der Waals metamaterials. *Light Sci. Appl.*, 2025, 14: 337. DOI: 10.1038/s41377-025-01847-5

[9] Li S., Zhou W., Imroz K.A., et al. Disentangling high harmonic generation from surface and bulk states of a topological insulator. *Nat. Commun.*, 2026, 17: 7642. DOI: 10.1038/s41467-026-74310-7

[10] †Zhang X., van den Brink J., Li J. Impact of crystal symmetries and Weyl nodes on high-harmonic generation in Weyl semimetal TaAs. arXiv:2405.16125, 2024.

[11] †Faeyrman L., Zhang J., Ivanov M., et al. Sub-cycle field-driven dynamical Berry phase in solids. arXiv:2606.02238, 2026.

[12] Kitagawa T., Berg E., Rudner M.S., et al. Topological characterization of periodically driven quantum systems. *Phys. Rev. B*, 2010, 82: 235114. DOI: 10.1103/PhysRevB.82.235114

[13] Rudner M.S., Lindner N.H. Band structure engineering and non-equilibrium dynamics in Floquet topological insulators. *Nat. Rev. Phys.*, 2020, 2: 229-244. DOI: 10.1038/s42254-020-0170-z

[14] Lesko D.M.B., Weitz T., Wittigschlager S., et al. Optical control of electrons in a Floquet topological insulator. *Nat. Phys.*, 2026 (advance online). DOI: 10.1038/s41567-026-03429-7

[15] †Zhao C., Jurkovičová L., Zou X., et al. Floquet-engineering unveiled by high-harmonic generation. arXiv:2507.03791, 2025.

[16] Chassot F., Pulkkinen A., Kremer G., et al. Floquet topological state induced by light-driven band inversion in SnTe. *Nat. Phys.*, 2026, 22: 1282-1286. DOI: 10.1038/s41567-026-03341-0

[17] Merboldt M., Schüler M., Schmitt D., et al. Observation of Floquet states in graphene. *Nat. Phys.*, 2025, 21: 1093-1099. DOI: 10.1038/s41567-025-02889-7

[18] D'Alessio L., Rigol M. Long-time behavior of isolated periodically driven interacting lattice systems. *Phys. Rev. X*, 2014, 4: 041048. DOI: 10.1103/PhysRevX.4.041048

[19] Cavaletto S.M., Kowalczyk K.M., Navarrete F., et al. The attoscience of strong-field-driven solids. *Nat. Rev. Phys.*, 2025, 7: 38-49. DOI: 10.1038/s42254-024-00784-3

[20] Zhao Z., Zheng Z., Xu Z., et al. Orthogonal attosecond control of solid-state harmonics by optical waveforms and quantum geometry engineering. *J. Phys. D*, 2026, 59: 215104. DOI: 10.1088/1361-6463/ae6c35

[21] †Batista C., Menotti J.P., Kim D., et al. Field-driven helicity in solid-state high-harmonic generation. arXiv:2604.27750, 2026.

[22] Lorenzo B., Batista C., Jangjan M., et al. High harmonic spectroscopy from lower-order to higher-order topological insulators. *Phys. Rev. B*, 2026, 114: 084307. DOI: 10.1103/7zjc-4b4r

[23] †Mokhtari S., Jelic V., Purschke D.N., et al. Phonon-driven decoherence of high-harmonic generation in the solid-state. arXiv:2604.07543, 2026.

[24] Hu S.Q., Zhao H., Liu X.B., et al. Phonon-coupled high-harmonic generation for exploring nonadiabatic electron-phonon interactions. *Phys. Rev. Lett.*, 2024, 133: 156901. DOI: 10.1103/PhysRevLett.133.156901

[25] †Ilin D., Solntsev A.S., Iorsh I. Quantum optical signatures of band topology in solid-state high harmonics. arXiv:2604.20388, 2026.

[26] Mosquera J.F.P., Cistaro G., Malakhov M., et al. Topological phase transitions via attosecond x-ray absorption spectroscopy. *Rep. Prog. Phys.*, 2024, 87: 117901. DOI: 10.1088/1361-6633/ad889f

[27] Nayak A., Dumergue M., Mukhopadhyay S., et al. A high intensity attosecond light source in compact geometry at ELI ALPS user facility. *Ultrafast Science*, 2026, 6: 0171. DOI: 10.34133/ultrafastscience.0171

[28] †Tan P., Chen Y., Zhang Y., et al. Ultrafast μeV-precision bandgap engineering in low-dimensional topological insulators. arXiv:2511.16165, 2025.

[29] Neufeld O., Tancogne-Dejean N., Rubio A. Benchmarking functionals for strong-field light-matter interactions in adiabatic time-dependent density functional theory. *J. Phys. Chem. Lett.*, 2024, 15: 7254-7264. DOI: 10.1021/acs.jpclett.4c01383

[30] †Kim D., Oh J., Koh K., et al. Real-time dynamics of the two-step charge-density-wave transition in bulk 1T-TaS₂. arXiv:2608.02456, 2026.

[31] de la Torre A., Wang Q., Masoumi Y., et al. Dynamic phase transition in 1T-TaS₂ via a thermal quench. *Nat. Phys.*, 2025, 21: 1267-1274. DOI: 10.1038/s41567-025-02938-1

[32] Rivera-Dean J., Petrovic L., Lewenstein M., et al. Attosecond quantum optical interferometry. *Rep. Prog. Phys.*, 2026, 89: 047901. DOI: 10.1088/1361-6633/ae5847

[33] †Watanabe K. Symmetry-enforced agreement of Kohn-Sham and many-body Berry phases in the SSH-Hubbard chain. arXiv:2602.22578, 2026.

[34] Aich S., Seradjeh B. Wilson loop invariants and bulk-boundary correspondence in higher-order topological insulators with anticommuting mirror symmetries. *Phys. Rev. B*, 2026, 114: 065133. DOI: 10.1103/vcxm-dr2g

[35] Uzan-Narovlansky A.J., Faeyrman L., Brown G.G., et al. Observation of interband Berry phase in laser-driven crystals. *Nature*, 2024, 626: 66-71. DOI: 10.1038/s41586-023-06828-5

[36] Kiselev E.I. Dynamical breaking of inversion symmetry, strong second harmonic generation, and ferroelectricity with nonlinear phonons. *Phys. Rev. Lett.*, 2026, 137: 106903. DOI: 10.1103/lwpl-brrr

[37] Suh M.-G., Yang Q.-F., Yang K.Y., et al. Microresonator soliton dual-comb spectroscopy. *Science*, 2016, 354: 600-603. DOI: 10.1126/science.aah6516

[38] Shah K., Cangi A. Machine learning time propagators for time-dependent density functional theory simulations. *Mach. Learn.: Sci. Technol.*, 2026, 7: 035019. DOI: 10.1088/2632-2153/ae68d4

[39] †Zhao C., Zou X. Self-attention enabled quantum path analysis of high-harmonic generation in solids. arXiv:2510.12443, 2025.

[40] †Jacobsen N., Schüler M., Rubio A., et al. Probing topological Floquet states in graphene with ultrafast terahertz scanning tunneling microscopy. arXiv:2602.14875, 2026.
