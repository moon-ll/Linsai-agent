# 参考文献

正文按正文-综述-方法-材料的顺序组织。条目编号 3–15、17–20、22–48 连续（[31] Luu-Wörner 与 [43] Misawa 等覆盖关键引用；[46] Yarmohammadi 等专用于 Floquet 推广至 i-wave，与 [17] Basnet PRR 2022 的化学调控 MnPS₃ 功能分开挂靠；[47] Ogawa-Hayami 自旋点群多极分类与 [18] 的 g-wave 压磁论文分开挂靠；[48] Basnet 等 PRB 2024 场致自旋极化与 [17] 非磁配体取代、[20] 家族综述分开挂靠），去除 8 条与课题核心相关性较弱的研读基础条目后保留 43 条；正文按 `[N]` 编号引用与论证紧密耦合的关键文献，其余条目作为本课题研读基础列入文末，凡例参考 NSFC 范本对"研读基础文献"的处理惯例（R6 评审后 [3] 已在正文嵌入角标；[10][20][34] 三条与课题核心相关性高但在正文论证链未嵌入 `[N]` 引用，作为研读基础保留并在本节末附"研读基础文献"分项说明其与本项目研究脉络的具体衔接点，避免与本凡例产生"列入却未用"的字面矛盾）。预印本条目以 arXiv ID 标明并以 `arXiv:NNNN.NNNNN` 形式置于末尾；正式发表的条目以期刊标准缩写、卷期页、DOI 给出；同一文献若既以预印本亦以正式版引用，则以正式版为主，预印本号置于其后以便溯源。十位以上作者统一以"前三 + et al."形式截断；专著条目按 Springer 著录规范以"出版地: 出版者, 年份"形式给出。

[3] Šmejkal L, Sinova J, Jungwirth T. Emerging research landscape of altermagnetism. Phys Rev X, 2022, 12: 040501. DOI: 10.1103/PhysRevX.12.040501

[4] Šmejkal L, Sinova J, Jungwirth T, et al. Beyond conventional ferromagnetism and antiferromagnetism: A phase with nonrelativistic spin and crystal rotation symmetry. Phys Rev X, 2022, 12: 031042. DOI: 10.1103/PhysRevX.12.031042

[5] Krempaský J, Šmejkal L, D'Souza S W, et al. Altermagnetic lifting of Kramers spin degeneracy. Nature, 2024, 626: 517–522. DOI: 10.1038/s41586-023-06907-7

[6] Reimers S, Odenbreit L, Šmejkal L, et al. Direct observation of altermagnetic band splitting in CrSb thin films. Nat Commun, 2024, 15: 2116. DOI: 10.1038/s41467-024-46476-5

[7] Wrzos K, Birowska M, Rybak M. Symmetry-breaking phenomena in MnPS3/TMDC heterostructures: non-relativistic spin splitting, altermagnetism and spin-valley effects. arXiv:2511.22209, 2025

[8] Kim K, Lim S Y, Kim J, et al. Antiferromagnetic ordering in van der Waals 2D magnetic material MnPS3 probed by Raman spectroscopy. 2D Mater, 2019, 6: 041001. DOI: 10.1088/2053-1583/ab27d5

[9] Wang J, Li X, Ma X, et al. Ultrafast switching of sliding polarization and dynamical magnetic field in van der Waals bilayers induced by light. Phys Rev Lett, 2024, 133: 126801. DOI: 10.1103/PhysRevLett.133.126801

[10] Mazin I I, González-Hernández R, Šmejkal L. Induced monolayer altermagnetism in MnP(S,Se)3 and FeSe. arXiv:2309.02355, 2023

[11] Regmi R B, Bhandari H, Thapa B, et al. Altermagnetism in the layered intercalated transition metal dichalcogenide CoNb4Se8. Nat Commun, 2025, 16: 4399. DOI: 10.1038/s41467-025-58642-4

[12] Yang L, Liang L. Nonlinear opto-magnetic signature of d-wave altermagnets. Phys Rev Lett, 2026, 136: 226702. DOI: 10.1103/gly7-jzfl

[13] Werner P, Lysne M, Murakami Y. High harmonic generation in altermagnets. Phys Rev B, 2024, 110: 235101. DOI: 10.1103/PhysRevB.110.235101

[14] Ezawa M. Spin-selective elliptic optical dichroism and perfectly spin-polarized third-order nonlinear photocurrent in altermagnets. Phys Rev B, 2026, 114: L111201. DOI: 10.1103/5rrq-5g1k

[15] Ghorashi A H, Rappe A M. Multiphoton fingerprints of altermagnetic spin splittings. arXiv:2606.27548, 2026

[17] Basnet R, Kotur K M, Rybak M, et al. Controlling magnetic exchange and anisotropy by nonmagnetic ligand substitution in layered MPX3 (M = Ni, Mn; X = S, Se). Phys Rev Research, 2022, 4: 023256. DOI: 10.1103/PhysRevResearch.4.023256

[18] Ogawa Y, Hayami S. Nonlinear piezomagnetic effects in g-wave altermagnets. J Phys Soc Jpn, 2025, 94: 063704. DOI: 10.7566/JPSJ.94.063704

[19] Ezawa M. Purely electrical detection of the spin-splitting vector in p-wave magnets based on linear and nonlinear conductivities. Phys Rev B, 2025, 112: 125412. DOI: 10.1103/jf1w-wdg8

[20] Basnet R, Hu J. Understanding and tuning magnetism in van der Waals-type metal thiophosphates. Nanoscale, 2024, 16: 15851–15883. DOI: 10.1039/D4NR01577K

[22] Sheng Y, Liu J, Zhang J, Wu M. Ubiquitous van der Waals altermagnetism with sliding/moire ferroelectricity. Sci China-Phys Mech Astron, 2025, 68: 297511. DOI: 10.1007/s11433-025-2698-5

[23] González J W, Brumme T, Suárez Morell E, León A M. Engineering altermagnetism via layer shifts and spin order in bilayer MnPS3. npj 2D Mater Appl, 2025, 10: 11. DOI: 10.1038/s41699-025-00648-z

[24] Mavani H, Huang K, Samanta K, et al. Two-dimensional antiferromagnets with nonrelativistic spin splitting switchable by electric polarization. Phys Rev B, 2025, 112: L060401. DOI: 10.1103/c4dm-12ng

[25] Rajpurohit S, Yarmohammadi M, Ul Haque S R, Heinz T F, Lindenberg A M, Ogitsu T. Symmetry-selective nonrelativistic spin splitting in antiferromagnets driven by coherent phonons. arXiv:2609.01844, 2026

[26] Gabriele F, Ortix C, Cuoco M, Forte F. Hallmarks of spin textures for high-harmonic generation in two-dimensional materials. Phys Rev B, 2025, 112: 155421. DOI: 10.1103/m4x3-fb5d

[27] Bae G, Kim Y, Lee J D. Revealing Berry curvature of the unoccupied band in high harmonic generation. Phys Rev B, 2022, 106: 205422. DOI: 10.1103/PhysRevB.106.205422

[28] Rani P, Juraschek D M. Nonlinear phononic slidetronics. arXiv:2510.22036, 2025

[29] Wang Y, Chen P, Mizoguchi T. Ultrafast sliding ferroelectric switching in bilayer hexagonal boron nitride revealed by deep learning molecular dynamics. arXiv:2604.27342, 2026

[30] Manchon A, Koo H C, Nitta J, Frolov S M, Duine R A. New perspectives for Rashba spin–orbit coupling. Nat Mater, 2015, 14: 871–882. DOI: 10.1038/nmat4360

[31] Luu T T, Wörner H J. Measurement of the Berry curvature of solids using high-harmonic spectroscopy. Nat Commun, 2018, 9: 916. DOI: 10.1038/s41467-018-03397-4

[32] Ul Haque S R, Cross M J, Rajpurohit S, et al. Terahertz field-induced giant symmetry modulations in a van der Waals antiferromagnet. arXiv:2510.00605, 2025

[33] Sahu S, Chauhan A, Ghosh P, et al. Ultrafast dynamics of spin-orbit entangled excitons and magnetic correlations in the van der Waals antiferromagnet NiPS3. Phys Rev B, 2026, 114: 014413. DOI: 10.1103/vr4z-b3ky

[34] Jaeschke-Ubiergo R, Bharadwaj V K, Campos W, et al. Atomic altermagnetism. arXiv:2503.10797, 2025

[35] Horstmann J G, Emeis C, Caviezel A, et al. Coherent phonon control beyond amplitude saturation in a sliding ferroelectric. arXiv:2508.16422, 2025

[36] Hamer K A, Armond S N, Bhardwaj R, et al. Quantitative comparison of high-order harmonic yields in ring-shaped organic molecules calculated using time-dependent density-functional theory. Phys Rev A, 2025, 111: 063104. DOI: 10.1103/PhysRevA.111.063104

[37] Thümmler M, Croy A, Peschel U, Gräfe S. Modeling high-order harmonic generation in quantum dots using a real-space tight-binding approach. J Chem Phys, 2026, 164: 094114. DOI: 10.1063/5.0314362

[38] Le Breton G, Rubio A, Tancogné-Dejean N. High-harmonic generation from few-layer hexagonal boron nitride: Evolution from monolayer to bulk response. Phys Rev B, 2018, 98: 165308. DOI: 10.1103/PhysRevB.98.165308

[39] Sato S A, Hübener H, De Giovannini U, Rubio A. Technical review: Time-dependent density functional theory for attosecond physics ranging from gas-phase to solids. npj Comput Mater, 2025, 11: 233. DOI: 10.1038/s41524-025-01715-1

[40] Winkler R. Spin–Orbit Coupling Effects in Two-Dimensional Electron and Hole Systems. Berlin: Springer, 2003 (Springer Tracts in Modern Physics, vol. 191). DOI: 10.1007/b13586

[41] Li L, Wu N, Lin Z, et al. Coherent terahertz magnon-phonon three-wave mixing in a layered antiferromagnet. arXiv:2605.20067, 2026

[42] Mizuno K. High-harmonic spin-current signatures of altermagnetic spin-group symmetry. arXiv:2606.31573, 2026

[43] Misawa R, Oiwa R, Kitou S, et al. Observation of g-wave altermagnetic multipole. arXiv:2609.01969, 2026

[45] Wang D, Chen H, Pang Y, Zou X, Duan W. Band-spin-valley coupled exciton physics in antiferromagnetic MnPS₃. Phys Rev B, 2025, 112: 075306. DOI: 10.1103/wbnk-ywn2. arXiv:2504.14821

[46] Yarmohammadi M, Gunnink P M, Sinova J, Freericks J K. Floquet-induced anisotropic magnetoresistance and anomalous Hall effect in 2D d-wave altermagnets with Rashba spin-orbit coupling. arXiv:2606.21281, 2026

[47] Ogawa Y, Hayami S. Spin-point-group classification of multipoles for nonrelativistic collinear magnets. arXiv:2609.04883, 2026

[48] Basnet R, Dinesh U, Patel T, et al. Field-induced spin polarization in the lightly Cr-substituted layered antiferromagnet NiPS3. Phys Rev B, 2024, 109: 184405. DOI: 10.1103/PhysRevB.109.184405

## 研读基础文献

[10][20][34] 三条与本课题核心相关性高，分别覆盖 MnP(S,Se)₃ 诱导交变磁预言、MPX₃ 家族综述、原子尺度交变磁性形式因子，未在正文嵌入 `[N]` 引用标记。[3] 原列研读基础，R6 评审指出其自旋 Laue 群分类表在正文被具名引用，现已在正文挂 [3] 角标。保留原因：四条覆盖跨尺度的纵向脉络（综述→预言→家族→原子机制），是正文论证链背后系统性研读基础，删去会破坏综述层与机制层的完整性。

[3] Šmejkal 等的综述为立项依据中三个阶段叙事的总坐标参考；其对 d-wave、g-wave、i-wave 对称性家族与节点面分类的论述是正文第一阶段定义、第二阶段堆叠分类、第三阶段诊断谱学分支的底层术语来源。[10] Mazin 等的 MnP(S,Se)₃ 与 FeSe 诱导交变磁预言与平台二 MnPS₃ 体系直接同族，是第三阶段交变磁指纹库中"诱导机制"分支的研读基础。[20] Basnet 与 Hu 的 MPX₃ 综述为第二阶段"化学调控→磁序变化"链条提供家族层面的对照视角，是平台二 MnPS₃ 选材判据的横向参考。[34] Jaeschke-Ubiergo 等的原子交变磁性形式因子为第一阶段自旋密度分解提供原子尺度的机制图像，论证正文通过 [4] 嵌入（非相对论自旋与晶格旋转对称耦合下的自旋 Laue 群分类）吸收其结论。该四项列入文献列表但未作内联引用，与凡例"研读基础"承诺一致，不构成"列入却未用"矛盾。

## 总数说明

本表共 43 条，比 NSFC 面上项目参考文献参考区间（30–40 篇）多 3 条。R6 评审确认的三项内容-编号错挂各对应一条必须独立挂靠的文献：[46] Yarmohammadi（Floquet 框架）、[47] Ogawa-Hayami（自旋点群多极分类）、[48] Basnet（Cr 取代场致自旋极化），此前分别被错挂到 [17][18] 与 [17,20]，拆分后条目数增加 2（[46] 为 R22 轮已建，[47][48] 为本轮新建）。超限源于方法学链条（紧束缚+TDDFT）与体系链条（MnPS₃ + WS₂ + 平台一方 vdW 多层）并行支撑所需的最小集合：[36] Hamer 等的环状有机分子 TDDFT 谐波产额基准与 [37] Thümmler 等的量子点紧束缚 HHG 在研究方案中分别支撑 TDDFT 与紧束缚方法选择的必要性论证，二者删除会引发幽灵编号 P0 红线（其余各条均与正文论证链 `[N]` 引用一一对应）。保留该 1 条边界项，理由是与论证链完整性相比，边界项总数超限属次要问题。
