## 参考文献

编号后标 † 者为 arXiv 预印本，未见正式发表版；正式发表后另行替换。

APS 条目按出版方实际注册的 DOI 著录。DOI 含两类：短式（形如 `10.1103/xxxx-xxxx`，由出版方注册的短缩写）与长式（完整期刊路径），著录保留出版方原始形态以便反向追溯。

会议文献（AAAI）按系列号完整著录：卷号与期号同时列出，全作者不另折 et al.。

[1] Goulielmakis E, Loh Z H, Wirth A, et al. Real-time observation of valence electron motion. Nature, 2010, 466: 739-743. DOI: 10.1038/nature09212

[2] Cousin S L, Di Palo N, Buades B, et al. Attosecond streaking in the water window: A new regime of attosecond pulse characterization. Physical Review X, 2017, 7: 041030. DOI: 10.1103/PhysRevX.7.041030

[3] Pabst S, Dahlström J. Eliminating the dipole phase in attosecond pulse characterization using Rydberg wave packets. Physical Review A, 2016, 94: 013411. DOI: 10.1103/PhysRevA.94.013411

[4] Schultze M, Fieß M, Karpowicz N, et al. Delay in photoemission. Science, 2010, 328: 1658-1662. DOI: 10.1126/science.1189401

[5] Mairesse Y, Quéré F. Frequency-resolved optical gating for complete reconstruction of attosecond bursts. Physical Review A, 2005, 71: 011401. DOI: 10.1103/PhysRevA.71.011401

[6] Ren X, Li J, Yin Y, et al. Attosecond light sources in the water window. Journal of Optics, 2018, 20: 023001. DOI: 10.1088/2040-8986/aaa394

[7] Peschel J, Busto D, Plach M, et al. Attosecond dynamics of multi-channel single photon ionization. Nature Communications, 2022, 13: 5205. DOI: 10.1038/s41467-022-32780-5

[8] Inzani G, Di Palo N, Dolso G L, et al. Absolute delay calibration by analytical fitting of attosecond streaking measurements. Journal of Physics: Photonics, 2024, 6: 025007. DOI: 10.1088/2515-7647/ad252a

[9] Zhu X X, Gao Y T, Wang Y M, et al. Autocorrelation-based convolutional neural network for reconstruction of noisy attosecond streaking traces. Chinese Physics B, 2026, 35: 054204. DOI: 10.1088/1674-1056/ae3474

[10] Hutcheson L R, Hartmann M, Borisova G D, et al. Phase evolution of strong-field ionization. Physical Review Research, 2025, 7: L022074. DOI: 10.1103/PhysRevResearch.7.L022074

[11] White J, Chang Z. Attosecond streaking phase retrieval with neural network. Optics Express, 2019, 27: 4799-4807. DOI: 10.1364/OE.27.004799

[12] Huppert M, Jordan I, Wörner H J. Attosecond beamline with actively stabilized and spatially separated beam paths. Review of Scientific Instruments, 2015, 86: 123106. DOI: 10.1063/1.4937623

[13] Ishii N, Kaneshima K, Kitano K, et al. Carrier-envelope phase-dependent high harmonic generation in the water window using few-cycle infrared pulses. Nature Communications, 2014, 5: 3331. DOI: 10.1038/ncomms4331

[14] Eckle P, Pfeiffer A N, Cirelli C, et al. Attosecond ionization and tunneling delay time measurements in helium. Science, 2008, 322: 1525-1529. DOI: 10.1126/science.1163439

[15] Villeneuve D M, Hockett P, Vrakking M J J, et al. Coherent imaging of an attosecond electron wave packet. Science, 2017, 356: 1150-1153. DOI: 10.1126/science.aam8393

[16] Klünder K, Dahlström J M, Gisselbrecht M, et al. Probing single-photon ionization on the attosecond time scale. Physical Review Letters, 2011, 106: 143002. DOI: 10.1103/PhysRevLett.106.143002

[17] Li X, Liu X, Wang C, et al. Coulomb focusing in attosecond angular streaking. Light: Science & Applications, 2024, 13: 250. DOI: 10.1038/s41377-024-01600-4

[18] Kheifets A, Serov V, Vismarra F, et al. Rainbow retrieval of atomic time delays in attosecond streaking. Physical Review A, 2026, 113: 043103. DOI: 10.1103/9jcm-8gd8

[19] Shi H, Thumm U. Photoelectron–residual-ion interaction in angle-resolved streaked shake-up ionization of helium. Physical Review A, 2025, 111: 013119. DOI: 10.1103/PhysRevA.111.013119

[20] Li M, Wang H, Tahouri R, et al. Photoionization time delays probe electron correlations. Physical Review Letters, 2025, 135: 183202. DOI: 10.1103/ll25-15dm

[21]† Tarrant J, Kolorenč P, Khokhlova M, et al. Creating attosecond breathing ions by coherent shake-up. arXiv:2503.21976 [physics.atom-ph], 2025.

[22] Aygun J, Yaacoub D, Harris A L. Spectral phase pulse shaping alters photoionization time. Journal of Physics B: Atomic, Molecular and Optical Physics, 2026, 59: 125601. DOI: 10.1088/1361-6455/ae7acf

[23] Meier D, Viefhaus J, Hartmann G, et al. Reconstructing time-of-flight detector values of angular streaking using machine learning. Physical Review Accelerators and Beams, 2025, 28: 074601. DOI: 10.1103/csvm-858f

[24]† Zimmermann T, Ortmann L, Hofmann C, et al. Attosecond streaking delays in multi-electron systems. arXiv:1804.09583 [physics.chem-ph], 2018.

[25] Wang K, Fu Y, Li B, et al. Direct reconstruction of isolated XUV or soft x-ray attosecond pulses from high-harmonic generation streaking spectra. New Journal of Physics, 2023, 25: 083003. DOI: 10.1088/1367-2630/ace8b3

[26] Zhao X, Li S, Driver T, et al. Characterization of single-shot attosecond pulses with angular streaking photoelectron spectra. Physical Review A, 2022, 105: 013111. DOI: 10.1103/PhysRevA.105.013111

[27] Ortmann L, Landsman A S. Understanding attosecond streaking. Reports on Progress in Physics, 2024, 87: 086401. DOI: 10.1088/1361-6633/ad6278

[28] Itatani J, Quéré F, Yudin G L, et al. Attosecond streak camera. Physical Review Letters, 2002, 88: 173903. DOI: 10.1103/PhysRevLett.88.173903

[29]† Gao J, Hasan M, Liang H, et al. Bright 25-attosecond light pulses reach the one atomic unit of time. arXiv:2508.14774 [physics.atom-ph], 2025.

[30] Ardana-Lamas F, Cousin S L, Lignieres J, et al. Brilliant source of 19.2-attosecond soft X-ray pulses below the atomic unit of time. Ultrafast Science, 2025, 5: 0128. DOI: 10.34133/ultrafastscience.0128

[31] Han M, Liang H, Liu Y, et al. Comment on "Brilliant source of 19.2-attosecond soft X-ray pulses below the atomic unit of time". Ultrafast Science, 2026, 6: 0145. DOI: 10.34133/ultrafastscience.0145

[32] Jiang W C, Zhong M C, Fang Y K, et al. Time delays as attosecond probe of interelectronic coherence and entanglement. Physical Review Letters, 2024, 133: 163201. DOI: 10.1103/PhysRevLett.133.163201

[33] Xie W H, Li Z C, Li M, et al. Observation of attosecond time delays in above-threshold ionization. Physical Review Letters, 2024, 133: 183201. DOI: 10.1103/PhysRevLett.133.183201

[34] Zhu Y, Zhang Z, Zhang R, Zhou L. SinBasis Networks: Matrix-Equivalent Feature Extraction for Wave-Like Optical Spectrograms. Proceedings of the AAAI Conference on Artificial Intelligence, 2026, 40(16): 14014-14021. DOI: 10.1609/aaai.v40i16.38412

[35] Gao J, Hasan M, Liang H, et al. Bright isolated light pulses reaching 18 attoseconds from high-order harmonic generation by post-compressed Yb lasers. Nature Communications, 2026, 17: 8810. DOI: 10.1038/s41467-026-76827-3

[36] Ma Y, Ni H, Wu J. Attosecond ionization time delays in strong-field physics. Chinese Physics B, 2024, 33: 013201. DOI: 10.1088/1674-1056/ad0e5d

[37] Driver T, Mountney M, Wang J, et al. Attosecond delays in X-ray molecular ionization. Nature, 2024, 632: 762-767. DOI: 10.1038/s41586-024-07771-9

[38]† Ardana-Lamas F, Cousin S L, Lignieres J, et al. Reply to "Comment on 'Brilliant source of 19.2-attosecond soft X-ray pulses below the atomic unit of time'" by Han. arXiv:2511.08391 [physics.optics], 2025.

[39] Hasan M, Gao J, Liang H, et al. Time-domain measurement of Auger electron dynamics in xenon and krypton atoms after giant resonance photoionization. Physical Review Letters, 2026, 136: 163201. DOI: 10.1103/578k-kmw6

[40]† Xia M, Nishimiya K, Dong D, et al. Complex-gate all-optical frequency-resolved optical gating for ultrabroadband isolated attosecond pulse characterization. arXiv:2608.30516 [physics.optics], 2026.

---

文献条目 40 条，覆盖阿秒条纹理论与实验、光源、重建算法、时延物理与仪器方法五类。本申请书文献检索截止于 2026 年 9 月。

DOI 真实性由 CrossRef API（api.crossref.org/works/{DOI}）逐条反查标题、作者与卷期页码五件套核对。

arXiv 条目由 arxiv.org/abs/{id} 页核对提交日期、作者链与 journal_ref 字段，缺失 journal_ref 的条目一律标 † 以标识未见正式发表版。

检索范围覆盖 Web of Science、arXiv、IEEE Xplore、Scopus 与 CrossRef。