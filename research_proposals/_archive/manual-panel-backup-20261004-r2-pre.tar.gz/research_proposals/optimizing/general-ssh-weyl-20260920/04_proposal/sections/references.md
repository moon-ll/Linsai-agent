## 参考文献

下列编号为正文引用编号与文献条目的最终映射，与立项依据、研究内容、研究方案三章中的 [N] 一一对应，编号 1–35 连续无跳号。条目按"基础/转折/锚文/对照"四类组织，每条带 DOI 或 arXiv 编号反查锚。[7][8][12][13][15][17][18][20][22][29] 共 10 条尚无期刊版本，以 arXiv 编号定位并逐条注明预印本属性，其结论在正文各引用处均已标明该属性。

[1] S. Ghimire, A. D. DiChiara, E. Sistrunk, P. Agostini, L. F. DiMauro, and D. A. Reis, "Observation of high-order harmonic generation in a bulk crystal," Nat. Phys. 7, 138 (2011); DOI: 10.1038/nphys1847. 中红外激光驱动 ZnO 晶体的首次固体 HHG 实验观测，固体强场谐波谱学的起点。

[2] G. Vampa, C. R. McDonald, G. Orlando, D. D. Klug, P. B. Corkum, and T. Brabec, "Theoretical analysis of high-order harmonic generation in solids," Phys. Rev. Lett. 113, 073901 (2014); DOI: 10.1103/PhysRevLett.113.073901. 提出固体带间再碰撞图像并以半导体 Bloch 方程描述固体 HHG，把气相三步模型移植到凝聚态体系的理论奠基工作。

[3] E. N. Osika, A. Chacón, L. Ortmann, N. Suárez, J. A. Pérez-Hernández, B. Szafran, M. F. Ciappina, F. Sols, A. S. Landsman, and M. Lewenstein, "Wannier-Bloch approach to localization in high-harmonics generation in solids," Phys. Rev. X 7, 021017 (2017); DOI: 10.1103/PhysRevX.7.021017. Wannier-Bloch 表象下的半经典轨迹模型，把固体 HHG 解读为局域化电子的强场动力学过程。

[4] T. T. Luu and H. J. Wörner, "Measurement of the Berry curvature of solids using high-harmonic spectroscopy," Nat. Commun. 9, 916 (2018); DOI: 10.1038/s41467-018-03397-4. 以固体 HHG 圆二色性谱反演 Berry 曲率在动量空间的分布，确立 HHG 作为能带几何探针的可行性。

[5] C. Heide, Y. Kobayashi, D. R. Baykusheva, D. Jain, J. A. Sobota, M. Hashimoto, P. S. Kirchmann, S. Oh, T. F. Heinz, D. A. Reis, and S. Ghimire, "Probing topological phase transitions using high-harmonic generation," Nat. Photon. 16, 620 (2022); DOI: 10.1038/s41566-022-01050-7. (Bi₁₋ₓInₓ)₂Se₃ 化学掺杂拓扑相变体系中扫描相变点附近的 HHG 响应，把 HHG 探测推进到拓扑相变维度。

[6] O. Neufeld, N. Tancogne-Dejean, H. Hübener, U. De Giovannini, and A. Rubio, "Are there universal signatures of topological phases in high-harmonic generation? Probably not," Phys. Rev. X 13, 031011 (2023); DOI: 10.1103/PhysRevX.13.031011. 指出多种拓扑平庸体系可在 HHG 谱中展示"拓扑样"圆二色信号，单一 CD 判据不可靠，拓扑判据须以非拓扑对照体系标定边界。

[7] O. Sufyan and O. Neufeld, "Double circular dichroism high harmonic spectroscopy: An ultrafast probe for topological photocurrents," arXiv:2604.21121 [cond-mat.other] (2026). 预印本。Haldane 纳米片上提出双圆二色性（DCD）方法，以双圆偏振解耦体态与边缘态的拓扑光电流贡献。

[8] S. Li, W. Zhou, K. A. Imroz, Y. Tang, T. A. Townsend, V. Leshchenko, L. Boie, P. Agostini, A. S. Landsman, R. K. Kawakami, L. Yue, and L. F. DiMauro, "Disentangling high harmonic generation from surface and bulk states of a topological insulator," arXiv:2604.06051 [cond-mat.mes-hall] (2026). 预印本。以 6 nm 与 50 nm 厚度 Bi₂Se₃ 对比结合 MIR-THz 双色场，分离体态与拓扑表面态（TSS）的 HHG 贡献。

[9] D. Bauer and K. K. Hansen, "High-harmonic generation in solids with and without topological edge states," Phys. Rev. Lett. 120, 177401 (2018); DOI: 10.1103/PhysRevLett.120.177401. SSH 拓扑相带隙下方谐波产额比平庸相最高增强达 14 个数量级，提出边界态 HHG 探针的雏形。

[10] C. Jürß and D. Bauer, "High-harmonic generation in Su-Schrieffer-Heeger chains," Phys. Rev. B 99, 195428 (2019); DOI: 10.1103/PhysRevB.99.195428. 在同一 SSH 模型上逐一比较体相与边界态对谐波谱的贡献，确认拓扑边界态是 HHG 的增强源。

[11] S. Pooyan and D. Bauer, "Harmonic generation with topological edge states and electron-electron interaction," Phys. Rev. B 111, 014308 (2025); DOI: 10.1103/PhysRevB.111.014308; arXiv:2406.04114 [quant-ph]. SSH-Hubbard 模型精确对角化计算，证明适度电子-电子相互作用下拓扑相与平庸相的谐波产额差异依然保留。

[12] C.-T. Liu, J.-S. You, and H.-C. Hsu, "Even-harmonic generation from topological edge states in generalized Su-Schrieffer-Heeger models," arXiv:2608.22136 [cond-mat.mes-hall] (2026). 预印本。扩展 SSH（ESSH）与 Rice-Mele 模型中，局域光照移至链边界时拓扑相六阶以上偶次谐波增强、奇次谐波近乎消失，该选择定则源于粒子-空穴对称变换下边界态与价带间的破坏性干涉。

[13] C. S. Lange and L. B. Madsen, "Edge states and quantum optical high-harmonic generation from topological insulators," arXiv:2602.16454 [quant-ph] (2026). 预印本。压缩度（quadrature squeezing）在短链中可区分拓扑相，谐波谱在所有链长下均可区分拓扑相，两种探针互补。

[14] M. L. Bera, J. O. de Almeida, M. Dziurawiec, M. Płodzień, M. M. Maśka, M. Lewenstein, T. Graß, and U. Bhattacharya, "Topological phase detection through high-harmonic spectroscopy in extended Su-Schrieffer-Heeger chains," Phys. Rev. B 108, 214104 (2023); DOI: 10.1103/PhysRevB.108.214104; arXiv:2304.06697 [cond-mat.mes-hall]. 扩展 SSH 链通过填充调控在 HHG 谱中定量区分零、两、四个拓扑边缘模式的相。

[15] X. Zhang, J. van den Brink, and J. Li, "Impact of crystal symmetries and Weyl nodes on high-order harmonic generation in Weyl semimetal TaAs," arXiv:2405.16125 [cond-mat.mtrl-sci] (2024). 预印本。以 Jones 矩阵形式体系分析 TaAs 的 HHG 选择定则，反常偶次谐波由 C₂(z) 与破缺镜面 M_z 的晶体对称性主导，而非 Weyl 锥拓扑本身。

[16] P. Pilch, C. Zhu, S. Kovalev, R. M. A. Dantas, A. Bedoya-Pinto, S. S. P. Parkin, and Z. Wang, "Terahertz third-harmonic generation of lightwave driven Weyl fermions far from equilibrium," Nano Lett. 25, 16637 (2025); DOI: 10.1021/acs.nanolett.5c04143; arXiv:2508.16166 [cond-mat.str-el]. TaP 纳米薄膜室温多周期窄带太赫兹三次谐波实验，THG 强度对驱动场呈严格立方功率律 $I_{3f} \propto I_f^{3}$，线偏振最强、随椭圆度单调衰减至圆偏振为零；理论端基于 Boltzmann 输运，THG 非线性归因于 Weyl 费米子的场驱动动力学。

[17] A. de las Heras, O. Neufeld, and A. Rubio, "Pulse-duration-sensitive high harmonics and attosecond locally-chiral light from a chiral topological Weyl semimetal," arXiv:2603.05346 [physics.optics] (2026). 预印本。RhSi 手性 B20 立方结构（空间群 198）的 TDDFT 计算，以谐波阶 3、4、9 相干叠加合成非零瞬时扭转的 3D 电场，分量周期 666 as 与 533 as。

[18] R. K. Thakur, P. Venkat, A. Bharti, and G. Dixit, "Helicity-engineered nonlinear optical responses in photo-excited topological semimetals," arXiv:2609.06119 [physics.optics] (2026). 预印本。双圆极化泵浦-探测架构下 Weyl 半金属 HHG 的螺旋性敏感度，可作为电子-空穴退相干时钟。

[19] N. Rana, M. S. Mrudul, A. Bharti, S. Giri, and G. Dixit, "Nonlinear optical spectroscopy of nodal line semimetals," Phys. Rev. Applied 24, L021001 (2025); DOI: 10.1103/3xs5-km1v; arXiv:2508.16494 [physics.optics]. 节线半金属 NbSixTe₂ 的二维 HHG；节点几何（节点线与 Weyl 点）对 HHG 选择规则的影响随晶体对称性差异明显。

[20] B. Lorenzo, C. Batista, M. Jangjan, D. Kim, J. Menotti, F. Liu, W. Gao, S. Ghimire, C. Granados, and A. Chacón, "High harmonic spectroscopy from lower-order to higher-order topological insulators," arXiv:2508.15631 [cond-mat.mes-hall] (2025). 预印本。Kagome 紧束缚模型上对比 Haldane、Kane-Mele 与 breathing Kagome 相的 HHG 谱，拓扑相谐波产额相对平庸相增强上限两个数量级（摘要报告），其正文计算中拓扑半金属相 7 次谐波最高约 3 个数量级。

[21] Y. S. You, D. A. Reis, and S. Ghimire, "Anisotropic high-harmonic generation in bulk crystals," Nat. Phys. 13, 345 (2017); DOI: 10.1038/nphys3955. ZnO 块体晶体中 HHG 对晶体取向的各向异性依赖，给出非拓扑体系对称性基线的 ZnO 侧数据。

[22] M. F. Ciappina, "Solid-state high-order harmonic generation: Emerging frontiers in ultrafast and quantum light science," arXiv:2510.15207 [physics.optics] (2025). 预印本（2025 年 10 月提交）。综述，整合 Berry 相位与拓扑效应、激子与晶格运动、量子光驱动 HHG 三个前沿方向。

[23] L. Medic, J. Mravlje, A. Ramšak, and T. Rejec, "High-harmonic generation in semi-Dirac and Weyl semimetals with broken time-reversal symmetry: Exploration of the merging of Weyl nodes," Phys. Rev. B 109, 205130 (2024); DOI: 10.1103/PhysRevB.109.205130; arXiv:2402.12899 [cond-mat.mes-hall]. 反演破缺 Weyl 半金属到 semi-Dirac 转变的最小模型上以 SBE 扫描 Weyl 节点合并，反常 HHG 在节点合并形成的 semi-DSM 区域出现增强峰，源自对严格线性色散的高阶偏离。

[24] H. K. Avetissian and G. F. Mkrtchian, "High laser harmonics induced by the Berry curvature in time-reversal invariant materials," Phys. Rev. B 102, 245422 (2020); DOI: 10.1103/PhysRevB.102.245422; arXiv:2005.09449 [cond-mat.mes-hall]. 时间反演不变材料中 Berry 曲率诱导激光谐波的多体理论框架，其曲率修正项给出多带跃迁矩阵元几何修正的解析实现。

[25] A. Bharti, M. S. Mrudul, and G. Dixit, "High-harmonic spectroscopy of light-driven nonlinear anisotropic anomalous Hall effect in a Weyl semimetal," Phys. Rev. B 105, 155140 (2022); DOI: 10.1103/PhysRevB.105.155140. 反常谐波偏振方向与 Berry 曲率分量宇称的对应规则。

[26] S. Duan, L. Shi, P. Pilch, A. Reinold, S. Kovalev, R. M. A. Dantas, Y. Yang, F. Xiu, M. S. Vitiello, and Z. Wang, "Giant enhancement of terahertz high-harmonic generation by cavity engineering of a three-dimensional Dirac semimetal," Nano Lett. 26, 10554 (2026); DOI: 10.1021/acs.nanolett.6c03104; arXiv:2510.01760 [cond-mat.mes-hall]. Cd₃As₂ 纳米薄膜超表面微腔的皮秒太赫兹共振驱动，三次与五次谐波产额增强三个数量级以上；裸膜幂律指数约 2.3，微腔样品随驱动增强幂指数由 0.9 渐降至 0.3 进入近饱和区。

[27] X. Liu, L. Geng, X.-S. Kong, J. Zhang, Y.-K. Fang, and L.-Y. Peng, "Theoretical investigations of high harmonic generation in the Weyl semimetal WP₂," Phys. Rev. B 111, 184314 (2025); DOI: 10.1103/PhysRevB.111.184314. 以半导体 Bloch 方程对 type-II Weyl 半金属 β-WP₂ 的 HHG 选择定则与椭圆依赖给出理论分析（国内工作），与 [28] 的实验数据构成理论-实验配对。

[28] Y.-Y. Lv, J. Xu, S. Han, C. Zhang, Y. Han, J. Zhou, S.-H. Yao, X.-P. Liu, M.-H. Lu, H. Weng, Z. Xie, Y. B. Chen, J. Hu, Y.-F. Chen, and S. Zhu, "High-harmonic generation in Weyl semimetal β-WP₂ crystals," Nat. Commun. 12, 6437 (2021); DOI: 10.1038/s41467-021-26766-y. Type-II Weyl 半金属 β-WP₂ 晶体中实验观测到低阈值 VUV HHG，偶次谐波由 Weyl 点 spike-like Berry 曲率贡献。

[29] Q.-G. Fan, K. Lai, W.-h. Liu, Z. Wang, L.-W. Wang, and J.-W. Luo, "Revealing material-dependent bicircular high-order harmonic generation in 2D semiconductors via real-space trajectories," arXiv:2507.09234 [physics.optics] (2025). 预印本。以实空间轨迹模型对比 MoS₂ 与 hBN 在反向旋转双圆偏振脉冲下的 HHG 产额，MoS₂ 呈 1.5:1 与单色极限双峰、hBN 单调上升，差异源于 Bloch 反常速度与 Berry 曲率（国内工作）。

[30] S. P. S. Jessen, M. Mero, M. J. J. Vrakking, R. M. Turtos, P. Balling, and P. Jürgens, "Interplay between high-harmonic generation and photoluminescence in ZnO: Anisotropic spectral properties of harmonic emission and the role of excitons," Phys. Rev. B 112, 214311 (2025); DOI: 10.1103/b56l-hvgn; arXiv:2508.09364 [physics.optics]. 块体 ZnO 在短波红外强场激发下 HHG（奇次谐波、相干）与光致发光（非相干、近带边）双通道对比；第五次谐波在强度驱动下出现谱形转变、主导机制切换，该转变强度即正文 I_threshold 基准值。

[31] A. McPherson, G. Gibson, H. Jara, U. Johann, T. S. Luk, I. A. McIntyre, K. Boyer, and C. K. Rhodes, "Studies of multiphoton production of vacuum-ultraviolet radiation in the rare gases," J. Opt. Soc. Am. B 4, 595 (1987); DOI: 10.1364/JOSAB.4.000595. 气相高次谐波产生的首次实验观测。

[32] M. Ferray, A. L'Huillier, X. F. Li, L. A. Lompre, G. Mainfray, and C. Manus, "Multiple-harmonic conversion of 1064 nm radiation in rare gases," J. Phys. B 21, L31 (1988); DOI: 10.1088/0953-4075/21/3/001. 与 [31] 构成气相 HHG 起源双锚。

[33] P. Antoine, A. L'Huillier, and M. Lewenstein, "Attosecond pulse trains using high-order harmonics," Phys. Rev. Lett. 77, 1234 (1996); DOI: 10.1103/PhysRevLett.77.1234. 阿秒脉冲串的早期理论工作。

[34] P. B. Corkum and F. Krausz, "Attosecond science," Nat. Phys. 3, 381 (2007); DOI: 10.1038/nphys620. 阿秒科学的纲领性综述。

[35] O. Schubert, M. Hohenleutner, F. Langer, B. Urbanek, C. Lange, U. Huttner, D. Golde, T. Meier, M. Kira, S. W. Koch, and R. Huber, "Sub-cycle control of terahertz high-harmonic generation by dynamical Bloch oscillations," Nat. Photon. 8, 119 (2014); DOI: 10.1038/nphoton.2013.349. 传统半导体 GaSe 中亚周期 THz 高次谐波的相干控制。

## 编号映射说明

立项依据、研究内容与研究方案三章共 160 处编号引用，全部映射至上表 35 条条目，无未引用条目；正文交叉引用同一文献时使用同一编号，重复仅出现在正文中。条目按"基础/转折/锚文/对照"四类组织：[31]–[34] 为气相 HHG 与阿秒科学的历史锚，[35] 为传统半导体 HHG 锚，[22] 为固体 HHG 综述，[1]–[21] 与 [23]–[30] 逐一对应本课题四个研究方向的论证链。
