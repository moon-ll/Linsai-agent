## 参考文献

[1] Rasputnyi A., Chen Z., Birk M., Even Tzur M., Gorlach A., Krüger M., Kaminer I., Cohen O., Chekhova M. V., Tani F. High-harmonic generation by a bright squeezed vacuum. *Nature Physics* **20**(12), 1960–1965 (2024). DOI: 10.1038/s41567-024-02659-x; arXiv: 2403.15337. — BSV-HHG 首例实验基线；§1.1 / §1.2.2 / §1.3 问题 1 / §2.4 引用。

[2] Even Tzur M., Birk M., Gorlach A., Kaminer I., Krüger M., Cohen O. Generation of squeezed high-order harmonics. *Physical Review Research* **6**(3), 033079 (2024). DOI: 10.1103/PhysRevResearch.6.033079; arXiv: 2311.11257. — winding trail 量子态公式起点；§1.2.2 段 4 / §2.3 / §3.1 引用。

[3] Agafonov I. N., Chekhova M. V., Iskhakov T. Sh., Kanseri B., Leuchs G. Two-color bright squeezed vacuum. *Physical Review A* **82**(1), 011801(R) (2010). DOI: 10.1103/PhysRevA.82.011801; arXiv: 0910.4831. — 非简并与简并 PDC 双配置 BSV 的统计性质原始出处；与 [4] 同组，构成 $g^{(2)}(0)=2$ 与 $3+1/N$ 的文献双锚；§1.2.2 段 1 / §2.1 / §3.1 引用。

[4] Iskhakov T. Sh., Perez A. M., Spasibko K. Yu., Chekhova M. V., Leuchs G. Super-bunched bright squeezed vacuum state. *Optics Letters* **37**(11), 1919–1921 (2012). DOI: 10.1364/OL.37.001919; arXiv: 1202.1682. — $g^{(2)}(0)$ 双配置基线；§1.2.2 段 1 / §2.1 / §3.1 引用。

[5] Wu M., Browne D. A., Schafer K. J., Gaarde M. B. Multilevel perspective on high-order harmonic generation in solids. *Physical Review A* **94**(6), 063403 (2016). DOI: 10.1103/PhysRevA.94.063403; arXiv: 1609.09852. — 多带 SBE 方法学基础；§1.2.1 / §2.3 / §3.1 引用。

[6] Liu H., Li Y., You Y. S., Ghimire S., Heinz T. F., Reis D. A. High-harmonic generation from an atomically thin semiconductor. *Nature Physics* **13**(3), 262–265 (2017). DOI: 10.1038/nphys3946. — 单层 TMDC HHG 实验基线；§1.2.1 / §2.2 / §3.1 引用。

[7] Silva R. E. F., Blinov I. V., Rubtsov A. N., Smirnova O., Ivanov M. High-harmonic spectroscopy of ultrafast many-body dynamics in strongly correlated systems. *Nature Photonics* **12**(5), 266–270 (2018). DOI: 10.1038/s41566-018-0129-0; arXiv: 1704.08471. — 强关联体系 HHG 范式；§1.1 / §1.2.1 / §2.4 / §3.1 引用。

[8] Murakami Y., Eckstein M., Werner P. High-harmonic generation in Mott insulators. *Physical Review Letters* **121**(5), 057405 (2018). DOI: 10.1103/PhysRevLett.121.057405; arXiv: 1712.06460. — Mott HHG 理论奠基；§3.3 Floquet 平均场失效域接管路径同源；§1.1 / §2.4 / §3.3 引用。

[9] Li L., Lan P., He L., Cao W., Zhang Q., Lu P. Determination of electron band structure using temporal interferometry. *Physical Review Letters* **124**(15), 157403 (2020). DOI: 10.1103/PhysRevLett.124.157403; arXiv: 1908.07283. — HHG 时域干涉反演电子能带结构方法学范式；§1.3 问题 3 / §2.5 / §3.4 引用。

[10] Peschel U., et al. Two-particle tight-binding description of higher-harmonic generation in semiconductor nanostructures. *Physical Review B* **106**(24), 245307 (2022). DOI: 10.1103/PhysRevB.106.245307; arXiv: 2205.00522. — 实空间双粒子方案；§3.3 莫尔周期 5–10 nm 失效域接管路径对接；§2.3 / §3.3 引用。

[11] Li A., et al. Quantum interference visibility spectroscopy in two-color photoemission from tungsten needle tips. *Physical Review Letters* **126**(13), 137403 (2021). DOI: 10.1103/PhysRevLett.126.137403; arXiv: 2205.11161. — 双色钨针尖量子干涉可见度方法学锚点；$Q_F$ 自洽性检验参照；§1.3 问题 3 / §2.5 / §3.4 引用。

[12] Raab A.-K., et al. Highly versatile, two-color setup for high-order harmonic generation using spatial light modulators. *Review of Scientific Instruments* **95**(7), 073002 (2024). DOI: 10.1063/5.0212578; arXiv: 2405.11859. — SLM 双色场工程参照；§2.5 / §3.2 / §3.4 引用。

[13] Wu F., Xu Q., Wang Q., Chu Y., Li L., Tang J., Liu J., Tian J., Ji Y., Liu L., et al. Giant correlated gap and possible room-temperature correlated states in twisted bilayer MoS₂. *Physical Review Letters* **131**(25), 256201 (2023). DOI: 10.1103/PhysRevLett.131.256201. — 扭转双层 MoS₂ 莫尔超晶格室温关联态实验基线；ν = 1 处关联能隙 126 meV，临界温度高至 285 K；§1.2.3 (ii) / §2.3 / §3.3 引用。

[14] Hu S.-Q., et al. Solid-state high harmonic spectroscopy for all-optical band structure probing of high-pressure quantum states. *Proceedings of the National Academy of Sciences* **121**(6), e2316775121 (2024). DOI: 10.1073/pnas.2316775121. — 经典光 HHG 统计特征提取方法学范式；§2.2 / §3.1 引用。

[15] Boroumand N., et al. Quantum engineering of high harmonic generation. arXiv preprint arXiv: 2505.22536 (2025). — 量子工程化 HHG（QSHHG）框架与可见度型 QEF 标定方法学锚点；论文原文将所提框架命名为 "quantum sideband high harmonic generation (QSHHG)"，本申请书沿用该缩写。该条暂无正式期刊卷期，保留 arXiv 编号；§1.4 创新点 3 / §2.5 / §3.4 引用。

[16] Rivera-Dean J., et al. Nonclassical states of light after high-harmonic generation in semiconductors: a Bloch-based perspective. *Physical Review B* **109**(3), 035203 (2024). DOI: 10.1103/PhysRevB.109.035203; arXiv: 2309.14435. — 理论环节 Bloch 形式化锚点；§2.3 / §3.1 引用。

[17] Iglesias J. M., et al. High-order harmonic generation in 2D transition metal disulphides. *Applied Physics Letters* **119**(1), 012101 (2021). DOI: 10.1063/5.0055897. — 谱学环节 TMDC 7–9 阶谐波产额基线参照；§2.2 / §3.1 引用。

[18] Prajapati G. L., et al. Terahertz harmonic generation across the Mott insulator-metal transition. *Physical Review B* **113**(4), 045118 (2026). DOI: 10.1103/ydjj-xxcl; arXiv: 2410.01424. — 强关联 Mott 体系 THz 谐波实验可行性参照；§1.1 / §2.4 / §3.3 引用。

[19] Ghimire S., DiChiara A. D., Sistrunk E., Agostini P., DiMauro L. F., Reis D. A. Observation of high-order harmonic generation in a bulk crystal. *Nature Physics* **7**(2), 138–141 (2010). DOI: 10.1038/nphys1847. — 固体 HHG 领域开山文献；§1.2.1 引用。

[20] Schleich W., Wheeler J. A. Oscillations in photon distribution of squeezed states. *Journal of the Optical Society of America B* **4**(10), 1715–1721 (1987). DOI: 10.1364/JOSAB.4.001715. — BSV 在 Glauber 相干态基上的展开框架；§1.2.2 段 1 引用。

[21] Wilkinson M. D., et al. The FAIR guiding principles for scientific data management and stewardship. *Scientific Data* **3**, 160018 (2016). DOI: 10.1038/sdata.2016.18. — 数据与代码开放原则；§2.6 / §3.8 引用。

[22] Borrego Varillas R., et al. Roadmap on attosecond science. arXiv preprint arXiv: 2604.15085 (2026). — 阿秒科学领域 Roadmap 与跨学科协作规范；§2.6 / §3.8 引用。截至本申请书定稿日（2026-08）该条仍为预印本，未在 CrossRef 中检索到正式发表版。

[23] Vampa G., et al. Semiclassical analysis of high-harmonic generation in bulk crystals. *Physical Review B* **91**(6), 064302 (2015). DOI: 10.1103/PhysRevB.91.064302. — 固体半经典带间再碰撞机制参照；§3.3 引用。

[24] Luu T. T., Wörner H. J. Measurement of the Berry curvature of solids using high-harmonic spectroscopy. *Nature Communications* **9**, 916 (2018). DOI: 10.1038/s41467-018-03397-4. — Berry 曲率反演方法学范式；§1.1 段 1 引用。

[25] Lewenstein M., et al. Theory of high-harmonic generation by low-frequency laser fields. *Physical Review A* **49**(3), 2117–2132 (1994). DOI: 10.1103/PhysRevA.49.2117. — SFA 三步模型经典锚点；§3.5 引用。

[26] Even Tzur M., Cohen O. Motion of charged particles in bright squeezed vacuum. *Light: Science & Applications* **13**, 41 (2024). DOI: 10.1038/s41377-024-01381-w; arXiv: 2305.16831. — BSV 驱动能量标度底层动力学；§2.1 引用。

[27] Wang S., et al. Attosecond pulse synthesis from high-order harmonic generation in intense squeezed light. *Physical Review A* **112**(1), L011102 (2025). DOI: 10.1103/4x11-phs2; arXiv: 2406.10443. — BSV 驱动阿秒脉冲合成预言；§1.2.2 引用。

[28] de-la-Peña S., et al. Quantum electrodynamics in high-harmonic generation: multitrajectory Ehrenfest and exact quantum analysis. *Journal of Chemical Theory and Computation* **21**(1), 283–290 (2025). DOI: 10.1021/acs.jctc.4c01206; arXiv: 2409.13614. — SBE-Q 模型高压缩度区交叉验证工具；§3.3 / §3.7 引用。

[29] Jiang S., Dorfman K. Relative-intensity squeezing of high-order harmonic "twin beams". *Chinese Physics Letters* **43**(5), 050401 (2026). DOI: 10.1088/0256-307X/43/5/050401; arXiv: 2311.10390. — 强场 HHG 相对强度压缩谐波孪生光束理论预言；§1.2.2 / §3.4 引用。

[30] Gothelf R. V., et al. High-harmonic generation in a crystal driven by quantum light. *Physical Review A* **111**(6), 063105 (2025). DOI: 10.1103/PhysRevA.111.063105; arXiv: 2502.11803. — ZnO 单带模型 BSV 截止阶数推高机制层预言；§1.2.2 / §2.2 引用。

[31] Lange C. S., et al. Excitonic enhancement of squeezed light in quantum-optical high-harmonic generation from a Mott insulator. *Physical Review Letters* **135**(4), 043603 (2025). DOI: 10.1103/wyk5-k8tk; arXiv: 2503.15932. — Mott 体系激子能区压缩光增强机制预言；§1.2.3 / §2.4 / §3.3 引用。

[32] Even Tzur M., et al. Measuring and controlling the birth of quantum attosecond pulses. arXiv preprint arXiv: 2502.09427 (2025). — BSV 驱动阿秒量子态层析与场致隧穿量子统计继承实验先例；§1.2.2 / §2.5 / §3.4 引用。截至本申请书定稿日（2026-08）该条仍为预印本，未在 CrossRef 中检索到正式发表版。

[33] Wang L., et al. Quantum dial for high-harmonic generation. arXiv preprint arXiv: 2509.13518 (2025). — MoS₂ 单层 BSV 弱场调控谷电子学预言；§1.2.2 / §2.2 引用。截至本申请书定稿日（2026-08）该条仍为预印本，未在 CrossRef 中检索到正式发表版。

[34] Wang F., Yang C., Cui X., He L., Ou T., Jin R.-B., Liao Q., Lan P., Lu P. Quantum path control in high-order harmonic generation via squeezed lights. *Physical Review A* **112**(4), 043119 (2025). DOI: 10.1103/hph3-kzb2; arXiv: 2509.20876. — BSV 驱动量子路径选择与阿秒脉冲宽度压缩理论；§1.3 国内主线引用。

[35] Lemieux S., Jalil S. A., Purschke D. N., Boroumand N., Hammond T. J., Villeneuve D., Naumov A., Brabec T., Vampa G. Photon bunching in high-harmonic emission controlled by quantum light. *Nature Photonics* **19**(7), 767–771 (2025). DOI: 10.1038/s41566-025-01673-6; arXiv: 2404.05474. — ZnO 半导体 BSV 微扰经典驱动，观测超泊松边带谐波；§1.2.2 引用。

[36] Jiang Z., Pan S., Chen J., Zhu M., Zhao C., Wang Y., Zhang L., Han L., Xiong S., Wu D., Li W., Jiang S., Ni H., Wu J. Nonlinear atomic tunnelling boosted by bright squeezed vacuum. *Nature* (2026). DOI: 10.1038/s41586-026-10485-9; arXiv: 2604.05783. — BSV 驱动钠原子隧穿电离：300 nJ BSV 实现相当于 7.1 μJ 相干光的 20 倍非线性效率提升，角 streaking 标定有效强度；华东师范大学吴健团队；§1.3 国内主线引用。

[37] Wang Y., Dobrosavljević V., Choi E. S., Saito Y., Kawamoto A., Pustogow A., Dressel M., Popović D. Failed superconductivity in a Mott spin liquid material. arXiv preprint arXiv: 2507.10832 (2025). — 化学取代 κ-(BEDT-TTF)₂X 莫特自旋液体磁输运与交流磁化率测量；T → 0 全局超导失稳、超导畴嵌入金属逾渗团簇、磁场驱动超导-金属量子相变；§2.3 强关联对照磁输运涨落参照引用。截至本申请书定稿日（2026-09）该条仍为 arXiv 预印本，暂未在 CrossRef 中检索到正式发表版。