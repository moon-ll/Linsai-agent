# 参考文献

带 † 者为含 arXiv 版本的条目；标注"†纯 arXiv 预印本"的五条（[12][14][15][18][29]）截至本申请书定稿（2026 年 9 月）未检索到正式期刊发表版本。

[1] Ghimire S, DiChiara A D, Sistrunk E, Agostini P, DiMauro L F, Reis D A. Observation of high-order harmonic generation in a bulk crystal. Nat. Phys., 2011, 7: 138–141. DOI: 10.1038/nphys1847

[2] Yoshikawa N, Tamaya T, Tanaka K. High-harmonic generation in graphene enhanced by elliptically polarized light excitation. Science, 2017, 356: 736–738. DOI: 10.1126/science.aam8861

[3] Liu H, Li Y, You Y S, Ghimire S, Heinz T F, Reis D A. High-harmonic generation from an atomically thin semiconductor. Nat. Phys., 2017, 13: 262–265. DOI: 10.1038/nphys3946

[4] Vampa G, McDonald C R, Orlando G, Klug D D, Corkum P B, Brabec T. Theoretical analysis of high-harmonic generation in solids. Phys. Rev. Lett., 2014, 113: 073901. DOI: 10.1103/PhysRevLett.113.073901

[5] Luu T T, Wörner H J. High-order harmonic generation in solids: A unifying approach. Phys. Rev. B, 2016, 94: 115164. DOI: 10.1103/PhysRevB.94.115164

[6] Šmejkal L, Sinova J, Jungwirth T. Beyond conventional ferromagnetism and antiferromagnetism: A phase with nonrelativistic spin and crystal rotation symmetry. Phys. Rev. X, 2022, 12: 031042. DOI: 10.1103/PhysRevX.12.031042

[7] Krempaský J, Šmejkal L, D'Souza S W, Hajlaoui M, Springholz G, et al. Altermagnetic lifting of Kramers spin degeneracy. Nature, 2024, 626: 517–522. DOI: 10.1038/s41586-023-06907-7

[8] Long M, Weinberger T I, Wu Z, Hansen M F, Tao R, Shrestha M, et al. 3D bulk-resolved g-wave altermagnetic order parameter in CrSb. Nature, 2026, 656: 854–860. DOI: 10.1038/s41586-026-10902-z

[9] Ding J, Jiang Z, Chen X, Tao Z, Liu Z, et al. Large band splitting in g-wave altermagnet CrSb. Phys. Rev. Lett., 2024, 133: 206401. DOI: 10.1103/PhysRevLett.133.206401

[10] Reimers S, Odenbreit L, Šmejkal L, Strocov V N, Constantinou P, et al. Direct observation of altermagnetic band splitting in CrSb thin films. Nat. Commun., 2024, 15: 2116. DOI: 10.1038/s41467-024-46476-5

[11] Yang G, Li Z, Yang S, Li J, Zheng H, et al. Three-dimensional mapping of the altermagnetic spin splitting in CrSb. Nat. Commun., 2025, 16: 1442. DOI: 10.1038/s41467-025-56647-7

[12] Dal Din A, Usanov D A, Šmejkal L, D'Souza S W, Guo F, Amin O J, Dawa E M, Campion R P, Edmonds K W, Kiraly B, Rushforth A W, Polley C, Leandersson M, Golias E, Niu Y, Telkamp S, Krizek F, Hellenes A B, Priessnitz J, Campos W H, Krempaský J, Minár J, Jungwirth T, Dil J H, Wadley P. Unconventional relativistic spin polarization of electronic bands in an altermagnet. arXiv:2511.01690, 2025. †纯 arXiv 预印本。

[13] Osumi T, Souma S, Aoyama T, Yamauchi K, Honma A, Nakayama K, Takahashi T, Ohgushi K, Sato T. Observation of a giant band splitting in altermagnetic MnTe. Phys. Rev. B, 2024, 109: 115102. DOI: 10.1103/PhysRevB.109.115102

[14] Usanov D A, D'Souza S W, Dal Din A, Krempaský J, Guo F, Amin O J, et al. Discerning ground state and photoemission-induced spin textures in altermagnetic α-MnTe. arXiv:2603.16635, 2026. †纯 arXiv 预印本。

[15] Zeng M, Liu P, Zhu M-Y, Zheng N, Liu X-R, Zhu Y, Shao T-H, Hao Y-J, Ma X-M, Qu G, Kurleto R, Wutke D, Luo R-H, Dai Y, Zhang X, Miyamoto K, Shimada K, Okuda T, Tanaka K, Huang Y, Liu Q, Liu C. Non-altermagnetic spin texture in MnTe. arXiv:2511.02447, 2025. †纯 arXiv 预印本。

[16] Werner P, Lysne M, Murakami Y. High harmonic generation in altermagnets. Phys. Rev. B, 2024, 110: 235101. DOI: 10.1103/PhysRevB.110.235101

[17] Haag L F, Weber M, Leckron K, Šmejkal L, Sinova J, Schneider H C. Signatures of bulk g-wave altermagnetism in optically excited α-MnTe. Phys. Rev. Mater., 2026, 10: 074413. DOI: 10.1103/ypfs-fy39

[18] Mizuno K. High-harmonic spin-current signatures of altermagnetic spin-group symmetry. arXiv:2606.31573, 2026. †纯 arXiv 预印本。

[19] Liu J, Ma X, Zhang X, Jing W, Liu Z, Shen D. Symmetry-driven spin splitting in altermagnets: an angle-resolved photoemission spectroscopy perspective. Nano Convergence, 2026, 13: 6. DOI: 10.1186/s40580-026-00536-2. †亦见 arXiv:2602.13590.

[20] Ly O. High-harmonic spin and charge pumping in altermagnets. J. Phys.: Condens. Matter, 2026, 38: 175803. DOI: 10.1088/1361-648X/ae6385. †亦见 arXiv:2602.09738. 注：arXiv 版与期刊版元数据一致性以期刊版为准。

[21] Liu Y Q, Si M S, Zhang G P, Du H, Zhang Z M. Anisotropic high harmonic generation as a gauge of altermagnetism in RuO₂. Phys. Rev. B, 2025, 112: L081105. DOI: 10.1103/9gv7-vhxw

[22] Tancogne-Dejean N, Mücke O D, Kärtner F X, Rubio A. Impact of the electronic band structure in high-harmonic generation spectra of solids. Phys. Rev. Lett., 2017, 118: 087403. DOI: 10.1103/PhysRevLett.118.087403

[23] Hohenleutner M, Langer F, Schubert O, Knorr M, Huttner U, Koch S W, Kira M, Huber R. Real-time observation of interfering crystal electrons in high-harmonic generation. Nature, 2015, 523: 572–575. DOI: 10.1038/nature14652

[24] Suzuki T, Okazaki K. Time-resolved photoemission spectroscopy of quantum materials using high harmonic generation: probing electron–phonon interactions and non-equilibrium dynamics. Prog. Surf. Sci., 2025, 100: 100795. DOI: 10.1016/j.progsurf.2025.100795

[25] Amin O J, Dal Din A, Golias E, Niu Y, Zakharov A, et al. Nanoscale imaging and control of altermagnetism in MnTe. Nature, 2024, 636: 348–353. DOI: 10.1038/s41586-024-08234-x

[26] Liu Z, Kikuchi H, Wei Z, Asai S, Enderle M, Hansen U B, Garlea V O, Le M D, Nilsen G J, Zaliznyak I A, Masuda T. Observation of switchable chiral magnons in an altermagnet. Phys. Rev. Lett., 2026, 136: 236705. DOI: 10.1103/m8lc-f8gk. †亦见 arXiv:2605.14124.

[27] Li C, Hu M, Li Z, Wang Y, Chen W, Thiagarajan B, Leandersson M, Polley C, Kim T, Liu H, Fulga C, Vergniory M G, Janson O, Tjernberg O, van den Brink J. Topological Weyl altermagnetism in CrSb. Commun. Phys., 2025, 8: 311. DOI: 10.1038/s42005-025-02232-9. †亦见 arXiv:2405.14777.

[28] Lee S, Lee S, Jung S, Jung J, Kim D, et al. Broken Kramers degeneracy in altermagnetic MnTe. Phys. Rev. Lett., 2024, 132: 036702. DOI: 10.1103/PhysRevLett.132.036702

[29] Jaeschke-Ubiergo R, Bharadwaj V K, Campos W, Zarzuela R, Biniskos N, et al. Atomic altermagnetism. arXiv:2503.10797, 2025. †纯 arXiv 预印本。

[30] Liu Y-Y, Zhao K, He P, Jiang Y-J, Huang H-D, Teng H, Wei Z-Y, et al. High harmonic generation experiments based on solid-state supercontinuum. Acta Phys. Sin., 2017, 66: 134207. DOI: 10.7498/aps.66.134207

[31] Silva R E F, Blinov I V, Rubtsov A N, Smirnova O, Ivanov M. High-harmonic spectroscopy of ultrafast many-body dynamics in strongly correlated systems. Nat. Photonics, 2018, 12: 266–270. DOI: 10.1038/s41566-018-0129-0

[32] Vampa G, Hammond T J, Thiré N, Schmidt B E, Légaré F, McDonald C R, Brabec T, Corkum P B. Linking high harmonics from gases and solids. Nature, 2015, 522: 462–464. DOI: 10.1038/nature14517
